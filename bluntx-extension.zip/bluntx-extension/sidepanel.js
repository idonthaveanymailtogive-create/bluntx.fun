const list = document.getElementById("list");
const meta = document.getElementById("meta");
const form = document.getElementById("paste-form");
const input = document.getElementById("addr");
const pasteError = document.getElementById("paste-error");
const detect = globalThis.BluntXDetect;

const LABELS = { low: "Low risk", caution: "Caution", high: "High risk" };
function label(level, score) {
  if (!LABELS[level]) return "Checking…";
  const base = score && score.lowData ? "Caution: not enough data" : LABELS[level];
  return score && typeof score.points === "number" ? `${base} · ${score.points}` : base;
}

function setPasteError(msg) {
  if (!msg) {
    pasteError.hidden = true;
    pasteError.textContent = "";
    return;
  }
  pasteError.hidden = false;
  pasteError.textContent = msg;
}

function render(coins) {
  const entries = Object.entries(coins || {});
  const rank = { high: 0, caution: 1, unknown: 2, low: 3 };
  entries.sort((a, b) => (rank[a[1]?.level] ?? 9) - (rank[b[1]?.level] ?? 9));
  meta.textContent = entries.length ? `${entries.length} coin${entries.length === 1 ? "" : "s"} on this tab` : "Coins on this tab";
  if (!entries.length) {
    list.replaceChildren(mk("li", { class: "empty", text: "Turn BluntX on for a supported trading or explorer site, or paste a token address above. Coins are rated Low risk, Caution or High risk, with a risk score and the findings behind it." }));
    return;
  }
  list.replaceChildren();
  for (const [mint, score] of entries) {
    const level = LABELS[score?.level] ? score.level : "unknown";
    const name = score?.facts?.symbol || score?.facts?.name || mint.slice(0, 6);
    const kids = [
      mk("div", { class: "row" }, [mk("span", { class: "bx-badge", "data-level": level, text: label(level, score) }), mk("span", { class: "name", text: String(name) })]),
      mk("div", { class: "mint", text: String(mint) })
    ];
    if (typeof score?.points === "number") {
      // v3: big score and the three main reasons, with every finding folded underneath.
      kids.push(mk("div", { class: "score" }, [mk("span", { class: "num", text: String(score.points) }), mk("span", { class: "of", text: "risk points" })]));
      const top = Array.isArray(score.top) ? score.top.slice(0, 3) : [];
      if (top.length) kids.push(mk("ol", { class: "why", "aria-label": "Main reasons" }, top.map((t) => mk("li", { text: String(t) }))));
      if (score.confidence) kids.push(mk("p", { class: "conf", text: `Data confidence: ${score.confidence.level} (${score.confidence.pct}%)` }));
      const all = (score.reasons || []).slice(score.confidence ? 2 : 1);
      if (all.length) kids.push(mk("details", { class: "more" }, [mk("summary", { text: `All findings (${all.length})` }), mk("ul", { class: "reasons" }, all.map((r) => mk("li", { text: String(r) })))]));
    } else {
      kids.push(mk("ul", { class: "reasons" }, (score?.reasons || []).map((r) => mk("li", { text: String(r) }))));
    }
    list.append(mk("li", { class: level }, kids));
  }
}

function mk(tag, attrs, kids) {
  const n = document.createElement(tag);
  if (attrs) for (const k of Object.keys(attrs)) {
    if (k === "class") n.className = attrs[k]; else if (k === "text") n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]);
  }
  for (const c of kids || []) n.append(c);
  return n;
}

let lastCoins = {};

async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

async function load() {
  const tabId = await activeTabId();
  if (!tabId) return render(lastCoins);
  const res = await chrome.runtime.sendMessage({ type: "BX_GET_COINS", tabId });
  lastCoins = res?.snapshot?.coins || lastCoins;
  render(lastCoins);
}

async function scoreAddresses(addresses) {
  if (!addresses.length) {
    setPasteError("No token or contract address found in that text.");
    return;
  }
  setPasteError("");
  const tabId = await activeTabId();
  for (const address of addresses) {
    if (!lastCoins[address]) {
      lastCoins[address] = { level: "unknown", reasons: ["Checking public data…"], facts: { mint: address } };
    }
  }
  render(lastCoins);
  const res = await chrome.runtime.sendMessage({ type: "BX_SCORE_MINTS", tabId, mints: addresses });
  if (!res?.ok) {
    setPasteError(res?.error || "Could not score that address.");
    return;
  }
  lastCoins = { ...lastCoins, ...(res.scores || {}) };
  render(lastCoins);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) {
    setPasteError("Paste a token or contract address first.");
    return;
  }
  const addresses = detect.extractFromText(text, { loose: true });
  await scoreAddresses(addresses);
});

async function consumePending() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "BX_GET_PENDING_CHECK" });
    const pending = res?.pending;
    if (!pending) return;
    await chrome.runtime.sendMessage({ type: "BX_CLEAR_PENDING_CHECK" });
    const addresses = pending.addresses?.length ? pending.addresses : detect.extractFromText(pending.text || "", { loose: true });
    if (pending.text && !input.value) input.value = pending.text;
    if (addresses.length) await scoreAddresses(addresses);
    else if (pending.text) setPasteError("No token or contract address found in the selected text.");
  } catch {
    // ignore
  }
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "BX_TAB_COINS") {
    lastCoins = { ...lastCoins, ...(message.coins || {}) };
    render(lastCoins);
  }
  if (message?.type === "BX_PENDING_CHECK") {
    const addresses = message.addresses?.length ? message.addresses : detect.extractFromText(message.text || "", { loose: true });
    if (message.text && !input.value) input.value = message.text;
    scoreAddresses(addresses);
  }
});

load();
consumePending();
setInterval(load, 2000);
