const list = document.getElementById("list");
const meta = document.getElementById("meta");

const LABELS = { low: "Low risk", caution: "Caution", high: "High risk" };
function label(level, score) {
  if (!LABELS[level]) return "Checking…";
  return score && typeof score.points === "number" ? `${LABELS[level]} · ${score.points}` : LABELS[level];
}

function render(coins) {
  const entries = Object.entries(coins || {});
  const rank = { high: 0, caution: 1, unknown: 2, low: 3 };
  entries.sort((a, b) => (rank[a[1]?.level] ?? 9) - (rank[b[1]?.level] ?? 9));
  meta.textContent = entries.length ? `${entries.length} coin${entries.length === 1 ? "" : "s"} on this tab` : "Coins on this tab";
  if (!entries.length) {
    list.replaceChildren(mk("li", { class: "empty", text: "Turn BluntX on for a pump.fun tab. Coins found on the page will show up here with a Low risk, Caution or High risk rating, a risk score and the findings behind it." }));
    return;
  }
  list.replaceChildren();
  for (const [mint, score] of entries) {
    const level = LABELS[score?.level] ? score.level : "unknown";
    const name = score?.facts?.symbol || score?.facts?.name || mint.slice(0, 6);
    list.append(mk("li", null, [
      mk("div", { class: "row" }, [mk("span", { class: "bx-badge", "data-level": level, text: label(level, score) }), mk("span", { class: "name", text: String(name) })]),
      mk("div", { class: "mint", text: String(mint) }),
      mk("ul", { class: "reasons" }, (score?.reasons || []).map((r) => mk("li", { text: String(r) })))
    ]));
  }
}

function mk(tag, attrs, kids) {
  const n = document.createElement(tag);
  if (attrs) for (const k of Object.keys(attrs)) {
    if (k === "class") n.className = attrs[k]; else if (k === "text") n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]);
  }
  for (const c of kids || []) n.append(c);
  return n;
}


async function load() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return render({});
  const res = await chrome.runtime.sendMessage({ type: "BX_GET_COINS", tabId: tab.id });
  render(res?.snapshot?.coins || {});
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "BX_TAB_COINS") render(message.coins || {});
});

load();
setInterval(load, 2000);
