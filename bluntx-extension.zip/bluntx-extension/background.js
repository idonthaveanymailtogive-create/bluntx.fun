/* global BluntXDetect, BluntXScoring, BluntXCore */
importScripts("detect.js", "core.js", "scoring.js");

const { pairsFor, toExtensionScore, isEvmAddress } = BluntXScoring;
const { isSupportedUrl, siteNameForUrl, extractFromText, normalizeAddress } = BluntXDetect;

const CACHE_TTL_MS = 5 * 60 * 1000;
const DEX_INTERVAL_MS = 1500;
const DEX_BATCH_SIZE = 20;
const CACHE_PREFIX = "bx_cache_v3_";

const tabEnabled = new Map();
const tabCoins = new Map();

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

class RateLimiter {
  constructor(minIntervalMs) {
    this.minIntervalMs = minIntervalMs;
    this.queue = [];
    this.running = false;
    this.nextAt = 0;
  }
  enqueue(fn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
      this.drain();
    });
  }
  async drain() {
    if (this.running) return;
    this.running = true;
    while (this.queue.length) {
      const wait = this.nextAt - Date.now();
      if (wait > 0) await sleep(wait);
      const job = this.queue.shift();
      try {
        const result = await job.fn();
        this.nextAt = Date.now() + this.minIntervalMs;
        job.resolve(result);
      } catch (err) {
        this.nextAt = Date.now() + this.minIntervalMs;
        job.reject(err);
      }
    }
    this.running = false;
  }
}

const dexLimiter = new RateLimiter(DEX_INTERVAL_MS);

const memoryCache = new Map();
const dexPending = new Map();
let dexBatchQueue = new Set();
let dexBatchWaiters = new Map();
let dexBatchTimer = null;

function cacheKeyFor(address) {
  return CACHE_PREFIX + (normalizeAddress(address) || address);
}

async function cacheGet(mint) {
  const key = cacheKeyFor(mint);
  const mem = memoryCache.get(key);
  if (mem && Date.now() - mem.cachedAt < CACHE_TTL_MS) return mem;
  try {
    const stored = await chrome.storage.local.get(key);
    const row = stored[key];
    if (row && Date.now() - row.cachedAt < CACHE_TTL_MS) {
      memoryCache.set(key, row);
      return row;
    }
  } catch {
    // storage can fail in tests; ignore
  }
  return null;
}

async function cacheSet(mint, row) {
  const key = cacheKeyFor(mint);
  const packed = { ...row, cachedAt: Date.now() };
  memoryCache.set(key, packed);
  try {
    await chrome.storage.local.set({ [key]: packed });
  } catch {
    // ignore
  }
  return packed;
}

async function fetchJson(url, timeoutMs = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { accept: "application/json" }
    });
    const text = await res.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 200) };
    }
    return { ok: res.ok, status: res.status, headers: res.headers, body };
  } finally {
    clearTimeout(t);
  }
}

function scheduleDexBatch() {
  if (dexBatchTimer) return;
  dexBatchTimer = setTimeout(flushDexBatch, 250);
}

async function flushDexBatch() {
  dexBatchTimer = null;
  const mints = [...dexBatchQueue].slice(0, DEX_BATCH_SIZE);
  mints.forEach((m) => dexBatchQueue.delete(m));
  if (!mints.length) return;
  const waiters = mints.map((m) => [m, dexBatchWaiters.get(m)]).filter((x) => x[1]);
  mints.forEach((m) => dexBatchWaiters.delete(m));

  try {
    const result = await dexLimiter.enqueue(async () => {
      const url = `https://api.dexscreener.com/latest/dex/tokens/${mints.join(",")}`;
      const res = await fetchJson(url);
      if (res.status === 429) {
        await sleep(4000);
        throw new Error("DexScreener rate-limited (HTTP 429)");
      }
      if (!res.ok) throw new Error(`DexScreener HTTP ${res.status}`);
      return res.body;
    });
    const pairs = Array.isArray(result?.pairs) ? result.pairs : [];
    for (const [mint, deferred] of waiters) {
      deferred.resolve({ pairs, error: null });
    }
  } catch (err) {
    for (const [, deferred] of waiters) {
      deferred.resolve({ pairs: [], error: String(err.message || err) });
    }
  }

  if (dexBatchQueue.size) scheduleDexBatch();
}

function requestDex(mint) {
  if (dexPending.has(mint)) return dexPending.get(mint);
  const promise = new Promise((resolve) => {
    dexBatchWaiters.set(mint, { resolve });
    dexBatchQueue.add(mint);
    scheduleDexBatch();
  });
  dexPending.set(mint, promise);
  promise.finally(() => dexPending.delete(mint));
  return promise;
}

async function searchDex(address) {
  return dexLimiter.enqueue(async () => {
    const url = `https://api.dexscreener.com/latest/dex/search/?q=${encodeURIComponent(address)}`;
    const res = await fetchJson(url);
    if (res.status === 429) {
      await sleep(4000);
      throw new Error("DexScreener rate-limited (HTTP 429)");
    }
    if (!res.ok) throw new Error(`DexScreener HTTP ${res.status}`);
    const pairs = Array.isArray(res.body?.pairs) ? res.body.pairs : [];
    return { pairs, error: null };
  });
}

// Deep checks (RugCheck, Solana RPC, GoPlus, honeypot.is, public EVM RPC) run through core.js, the same code as
// bluntx.fun. core.js paces each API host (GoPlus about 1 call / 2.1 s, RugCheck about 1 / 1.1 s), caches responses for
// two minutes and falls back to the RugCheck summary when the full report is rate-limited.
BluntXCore.configure({ rpcs: ["https://public.rpc.solanavibestation.com", "https://solana-rpc.publicnode.com"] });
const scorePending = new Map();

async function scoreMint(mint, { force = false } = {}) {
  const address = normalizeAddress(mint) || mint;
  if (!force) {
    const cached = await cacheGet(address);
    if (cached?.score) return cached;
  }
  if (scorePending.has(address)) return scorePending.get(address);
  const job = (async () => {
    let pairs = [];
    let dexError = null;
    try {
      const res = await requestDex(address);
      pairs = pairsFor(res.pairs, address);
      dexError = res.error;
    } catch (err) {
      dexError = String(err.message || err);
    }

    if (!pairs.length && !dexError) {
      try {
        const searched = await searchDex(address);
        pairs = pairsFor(searched.pairs, address);
        if (!pairs.length && searched.pairs.length) {
          // The query may have been a pair address (DexScreener, DEXTools, GeckoTerminal).
          const evmAddr = isEvmAddress(address);
          const exact = searched.pairs.filter((p) => p && (evmAddr
            ? String(p.pairAddress || "").toLowerCase() === address
            : p.pairAddress === address));
          const use = exact.length ? exact : searched.pairs;
          const token = (use[0] && use[0].baseToken && use[0].baseToken.address) || address;
          const tokenPairs = pairsFor(use, token);
          if (token !== address && tokenPairs.length) return scoreMint(token, { force: true });
        }
      } catch (err) {
        if (!dexError) dexError = String(err.message || err);
      }
    }

    const d = await BluntXCore.gather(address, "auto", { pairs, dexError, rpcMode: "fallback" });
    const score = toExtensionScore(d, BluntXCore.score(d));
    return cacheSet(address, { mint: address, score });
  })();
  scorePending.set(address, job);
  job.finally(() => scorePending.delete(address));
  return job;
}

async function scoreMints(mints) {
  const unique = [...new Set((mints || []).map((m) => normalizeAddress(m) || m).filter(Boolean))];
  const results = {};
  await Promise.all(
    unique.map(async (mint) => {
      try {
        const row = await scoreMint(mint);
        results[row.mint || mint] = row.score;
      } catch (err) {
        results[mint] = {
          level: "unknown",
          reasons: [`Could not score this address: ${err.message || err}`],
          facts: { mint }
        };
      }
    })
  );
  return results;
}

async function loadEnabledFromSession() {
  try {
    const { enabledTabs = {} } = await chrome.storage.session.get("enabledTabs");
    Object.entries(enabledTabs).forEach(([id, on]) => {
      if (on) tabEnabled.set(Number(id), true);
    });
  } catch {
    // session storage may be unavailable in older browsers
  }
}

async function persistEnabled() {
  const enabledTabs = {};
  for (const [id, on] of tabEnabled.entries()) {
    if (on) enabledTabs[id] = true;
  }
  try {
    await chrome.storage.session.set({ enabledTabs });
  } catch {
    // ignore
  }
}

async function inject(tabId) {
  await chrome.scripting.insertCSS({ target: { tabId }, files: ["content.css"] });
  await chrome.scripting.executeScript({ target: { tabId }, files: ["detect.js", "content.js"] });
}

async function setEnabled(tabId, enabled) {
  if (enabled) {
    tabEnabled.set(tabId, true);
    await persistEnabled();
    const tab = await chrome.tabs.get(tabId);
    if (!isSupportedUrl(tab.url || "")) {
      throw new Error("Auto-scan only runs on supported trading and explorer sites. You can paste an address in the side panel on any site.");
    }
    await inject(tabId);
    if (chrome.sidePanel?.setOptions) {
      await chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
    }
    try {
      await chrome.tabs.sendMessage(tabId, { type: "BX_ENABLE" });
    } catch {
      // content script will enable itself on inject
    }
  } else {
    tabEnabled.delete(tabId);
    tabCoins.delete(tabId);
    await persistEnabled();
    try {
      await chrome.tabs.sendMessage(tabId, { type: "BX_DISABLE" });
    } catch {
      // tab may not have a content script
    }
  }
  return { enabled: !!tabEnabled.get(tabId) };
}

function snapshot(tabId) {
  const coins = tabCoins.get(tabId) || {};
  return {
    enabled: !!tabEnabled.get(tabId),
    coins
  };
}

async function openSidePanel(tabId) {
  if (chrome.sidePanel?.setOptions && tabId) {
    try {
      await chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
    } catch {
      // ignore
    }
  }
  if (chrome.sidePanel?.open && tabId) {
    await chrome.sidePanel.open({ tabId });
  }
}

function ensureContextMenu() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "bx-check",
      title: "Check with BluntX",
      contexts: ["selection"]
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  loadEnabledFromSession();
  ensureContextMenu();
});
loadEnabledFromSession();
ensureContextMenu();

chrome.tabs.onRemoved.addListener((tabId) => {
  tabEnabled.delete(tabId);
  tabCoins.delete(tabId);
  persistEnabled();
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!tabEnabled.get(tabId)) return;
  if (changeInfo.status === "complete" && isSupportedUrl(tab.url || "")) {
    try {
      await inject(tabId);
      await chrome.tabs.sendMessage(tabId, { type: "BX_ENABLE" });
    } catch {
      // ignore reload races
    }
  }
});

if (chrome.contextMenus?.onClicked) {
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId !== "bx-check") return;
    const text = (info.selectionText || "").trim();
    const found = extractFromText(text, { loose: true });
    try {
      await chrome.storage.session.set({
        bxPendingCheck: { text, addresses: found, at: Date.now() }
      });
    } catch {
      // ignore
    }
    if (tab?.id) {
      try {
        await openSidePanel(tab.id);
      } catch {
        // Side panel may be unavailable
      }
    }
    try {
      await chrome.runtime.sendMessage({ type: "BX_PENDING_CHECK", text, addresses: found, tabId: tab?.id });
    } catch {
      // side panel may not be open yet; it will read session storage
    }
    if (found.length && tab?.id) {
      try {
        const scores = await scoreMints(found);
        const current = tabCoins.get(tab.id) || {};
        tabCoins.set(tab.id, { ...current, ...scores });
        chrome.runtime.sendMessage({ type: "BX_TAB_COINS", tabId: tab.id, coins: tabCoins.get(tab.id) }).catch(() => {});
      } catch {
        // scoring errors are shown in the side panel on the next load
      }
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = message.tabId || sender.tab?.id;
  const type = message.type;

  const reply = (promise) => {
    promise.then((value) => sendResponse({ ok: true, ...value })).catch((err) => {
      sendResponse({ ok: false, error: String(err.message || err) });
    });
    return true;
  };

  if (type === "BX_GET_STATUS") {
    return reply(
      Promise.resolve({
        enabled: tabId ? !!tabEnabled.get(tabId) : false,
        isSupported: false
      }).then(async (base) => {
        let isSupported = false;
        let url = "";
        let siteName = null;
        if (tabId) {
          try {
            const tab = await chrome.tabs.get(tabId);
            url = tab.url || "";
            isSupported = isSupportedUrl(url);
            siteName = siteNameForUrl(url);
          } catch {
            // ignore
          }
        }
        return {
          ...base,
          enabled: tabId ? !!tabEnabled.get(tabId) : false,
          isSupported,
          isPump: isSupported,
          siteName,
          url,
          snapshot: tabId ? snapshot(tabId) : null
        };
      })
    );
  }

  if (type === "BX_SET_ENABLED") {
    return reply(setEnabled(tabId, !!message.enabled).then((r) => ({ ...r })));
  }

  if (type === "BX_OPEN_SIDEPANEL") {
    return reply(openSidePanel(tabId).then(() => ({ opened: true })));
  }

  if (type === "BX_SCORE_MINTS") {
    return reply(
      scoreMints(message.mints || message.addresses || []).then((scores) => {
        if (tabId) {
          const current = tabCoins.get(tabId) || {};
          tabCoins.set(tabId, { ...current, ...scores });
        }
        return { scores };
      })
    );
  }

  if (type === "BX_PARSE_TEXT") {
    const addresses = extractFromText(message.text || "", { loose: true });
    sendResponse({ ok: true, addresses });
    return false;
  }

  if (type === "BX_COINS_UPDATED") {
    if (tabId) {
      tabCoins.set(tabId, message.coins || {});
      chrome.runtime.sendMessage({ type: "BX_TAB_COINS", tabId, coins: message.coins || {} }).catch(() => {});
    }
    sendResponse({ ok: true });
    return false;
  }

  if (type === "BX_GET_COINS") {
    sendResponse({ ok: true, snapshot: tabId ? snapshot(tabId) : { enabled: false, coins: {} } });
    return false;
  }

  if (type === "BX_GET_PENDING_CHECK") {
    return reply(
      chrome.storage.session.get("bxPendingCheck").then((stored) => ({ pending: stored.bxPendingCheck || null }))
    );
  }

  if (type === "BX_CLEAR_PENDING_CHECK") {
    return reply(chrome.storage.session.remove("bxPendingCheck").then(() => ({ cleared: true })));
  }

  return false;
});
