// BluntX extension scoring adapter. The rules themselves live in core.js, which is the same file the
// https://bluntx.fun checker runs, so both always give the same rating: under 25 = Low risk, 25–54 = Caution,
// 55+ = High risk, with forced High risk findings, category limits and a data-confidence floor
// (a Low-confidence report is never shown as Low risk).

// Wrapped in a function scope so its names never clash with background.js in the shared worker scope.
(() => {
  const LABEL = { low: "Low risk", caution: "Caution", high: "High risk", unknown: "Checking" };
  const LEVEL_OF = { green: "low", yellow: "caution", red: "high" };

  function isEvmAddress(address) {
    return /^0x[a-fA-F0-9]{40}$/i.test(address || "");
  }

  function liqOf(p) { return (p && p.liquidity && p.liquidity.usd) || 0; }

  function addrEq(a, b, evm) {
    if (!a || !b) return false;
    return evm ? String(a).toLowerCase() === String(b).toLowerCase() : a === b;
  }

  // Pairs where this address is the base or quote token. Prefer base-token matches, then higher liquidity.
  function pairsFor(pairs, mint) {
    const evm = isEvmAddress(mint);
    return (Array.isArray(pairs) ? pairs : [])
      .filter((p) => p && (addrEq(p.baseToken && p.baseToken.address, mint, evm) || addrEq(p.quoteToken && p.quoteToken.address, mint, evm)))
      .sort((a, b) => {
        const aBase = addrEq(a.baseToken && a.baseToken.address, mint, evm) ? 1 : 0;
        const bBase = addrEq(b.baseToken && b.baseToken.address, mint, evm) ? 1 : 0;
        if (bBase !== aBase) return bBase - aBase;
        return liqOf(b) - liqOf(a);
      });
  }

  function tokenSide(pair, mint) {
    const evm = isEvmAddress(mint);
    if (pair && addrEq(pair.baseToken && pair.baseToken.address, mint, evm)) return pair.baseToken;
    if (pair && addrEq(pair.quoteToken && pair.quoteToken.address, mint, evm)) return pair.quoteToken;
    return (pair && pair.baseToken) || null;
  }

  // Convert a core.js result into the compact shape the badges, overlay and side panel render (plain strings only).
  function toExtensionScore(d, s) {
    const mint = d.addr;
    if (!s || s.verdict === "error") {
      return { level: "unknown", points: null, reasons: [s && s.message ? s.message : "Public data is not available yet."], findings: [], facts: { mint } };
    }
    const level = LEVEL_OF[s.verdict] || "unknown";
    const meta = tokenSide(s.main, mint);
    const g = d.gp || {};
    const rcMeta = d.rug && d.rug.tokenMeta;
    const facts = {
      mint,
      name: (meta && meta.name) || g.token_name || (rcMeta && rcMeta.name) || null,
      symbol: (meta && meta.symbol) || g.token_symbol || (rcMeta && rcMeta.symbol) || null,
      dexId: s.main ? s.main.dexId : null,
      chainId: d.chain || null,
      liquidityUsd: (s.market && s.market.liq) || null,
      marketCap: (s.market && s.market.mcap) || null,
      top10: s.holders ? s.holders.top10 : null
    };
    const title = globalThis.BluntXCore.title(s)[0];
    const c = s.confidence;
    const findings = s.reasons.map((r) => ({ level: r.level, text: r.text, pts: r.pts || 0, capped: r.capped || 0 }));
    const reasons = [
      `${title} · risk score ${s.points}`,
      c ? `Data confidence: ${c.level} (${c.pct}%).` + (c.missing.length ? ` Not checked: ${c.missing.join(", ")}.` : "") + (c.partial.length ? ` Partly checked: ${c.partial.join(", ")}.` : "") : null,
      ...findings.map((f) => f.text + (f.pts ? ` (+${f.pts}${f.capped ? ", category limit" : ""})` : ""))
    ].filter(Boolean);
    // v3: the three findings that drive the score most, and a per-category summary.
    const top = (s.top || []).map((r) => r.text);
    const groups = (s.groups || []).map((g) => ({ key: g.key, title: g.title, level: g.level, pts: g.pts, cap: g.cap }));
    return {
      level, points: s.points, label: title, lowData: !!s.lowData, reasons, findings, facts, top, groups,
      confidence: c ? { level: c.level, pct: c.pct, missing: c.missing, partial: c.partial } : null,
      pool: s.pool || null
    };
  }

  const BluntXScoring = { LABEL, isEvmAddress, pairsFor, tokenSide, toExtensionScore };
  globalThis.BluntXScoring = BluntXScoring;
})();
