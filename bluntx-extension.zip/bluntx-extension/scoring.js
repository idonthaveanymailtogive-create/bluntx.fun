// BluntX extension scoring. Same points model and thresholds as the Solana checker on https://bluntx.fun:
// every token starts at 0 risk points; under 25 = Low risk, 25–54 = Caution, 55+ = High risk.
// Certain findings (active freeze authority, RugCheck "rugged" flag) are High risk automatically.
// Data: DexScreener pairs + the public RugCheck report (mint/freeze authority, top holders, risk findings).
// The extension does not query Solana RPC, so holder figures always come from RugCheck.

export const LABEL = { low: "Low risk", caution: "Caution", high: "High risk", unknown: "Checking" };

function liqOf(p) { return (p && p.liquidity && p.liquidity.usd) || 0; }

function usd(n) {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return "$" + (n / 1e3).toFixed(1) + "K";
  return "$" + Number(n).toFixed(0);
}
function ago(h) { return h < 1 ? Math.round(h * 60) + " min" : h < 48 ? Math.round(h) + "h" : Math.round(h / 24) + " days"; }

// Pairs on Solana where this mint is the base token.
export function pairsFor(pairs, mint) {
  return (Array.isArray(pairs) ? pairs : [])
    .filter((p) => p && p.chainId === "solana" && p.baseToken && p.baseToken.address === mint)
    .sort((a, b) => liqOf(b) - liqOf(a));
}

function holdersFromRugcheck(rc, pairs) {
  if (!rc || !Array.isArray(rc.topHolders) || !rc.topHolders.length) return null;
  const skip = {};
  pairs.forEach((p) => { skip[p.pairAddress] = 1; });
  const ka = rc.knownAccounts || {};
  Object.keys(ka).forEach((k) => { if (/AMM|LOCKER/i.test((ka[k] && ka[k].type) || "")) skip[k] = 1; });
  (rc.markets || []).forEach((m) => { if (m && m.pubkey) skip[m.pubkey] = 1; });
  let poolPct = 0;
  const users = [];
  rc.topHolders.forEach((h) => {
    const pct = Number(h.pct) || 0;
    if (skip[h.owner] || skip[h.address]) poolPct += pct; else users.push(pct);
  });
  const top = users.slice(0, 10);
  return { top10: top.reduce((s, x) => s + x, 0), top1: top.length ? top[0] : 0, poolPct };
}

export function scoreToken({ mint, pairs, rugcheck, rugcheckError, dexError, now }) {
  now = now || Date.now();
  const reasons = [];
  const findings = [];
  let pts = 0, forceHigh = false;
  const add = (level, text, p) => { findings.push({ level, text, pts: p || 0 }); reasons.push(text + (p ? ` (+${p})` : "")); pts += p || 0; };

  const ps = pairsFor(pairs, mint);
  const main = ps[0] || null;
  const rc = rugcheck && !rugcheck.error ? rugcheck : null;
  const facts = {
    mint,
    name: (main && main.baseToken.name) || (rc && rc.tokenMeta && rc.tokenMeta.name) || null,
    symbol: (main && main.baseToken.symbol) || (rc && rc.tokenMeta && rc.tokenMeta.symbol) || null,
    dexId: main ? main.dexId : null
  };

  if (!rc && !ps.length) {
    const why = [rugcheckError && `RugCheck: ${rugcheckError}`, dexError && `DexScreener: ${dexError}`].filter(Boolean);
    return { level: "unknown", points: null, reasons: why.length ? ["Public data is not available yet.", ...why] : ["Checking public data…"], findings, facts };
  }

  // ----- contract / authority (from RugCheck) -----
  if (rc && "mintAuthority" in rc) {
    if (rc.mintAuthority) add("bad", "Mint authority is active: additional tokens can be minted, diluting existing holders.", 35);
    else add("good", "Mint authority revoked: supply is fixed.");
    if (rc.freezeAuthority) { add("bad", "Freeze authority is active: holder balances can be frozen, preventing transfers or sales.", 40); forceHigh = true; }
    else add("good", "Freeze authority revoked: holder balances cannot be frozen.");
  } else add("warn", "Mint and freeze authority could not be verified (RugCheck unavailable).", 10);

  // ----- market (DexScreener) -----
  if (!ps.length) add("bad", "No trading market found on DexScreener. Selling may not be possible.", 25);
  else {
    const liq = ps.reduce((s, p) => s + liqOf(p), 0);
    const mcap = main.marketCap || main.fdv;
    const created = Math.min(...ps.map((p) => p.pairCreatedAt || Infinity));
    const vol24 = ps.reduce((s, p) => s + ((p.volume && p.volume.h24) || 0), 0);
    const buys = ps.reduce((s, p) => s + ((p.txns && p.txns.h24 && p.txns.h24.buys) || 0), 0);
    const sells = ps.reduce((s, p) => s + ((p.txns && p.txns.h24 && p.txns.h24.sells) || 0), 0);
    Object.assign(facts, { liquidityUsd: liq || null, marketCap: mcap || null, volumeH24: vol24, pairCreatedAt: isFinite(created) ? created : null });
    if (!liq) {
      add("info", main.dexId === "pumpfun" ? "Still on the pump.fun bonding curve (not yet migrated to a DEX pool)." : "No liquidity pool reported (likely still on a launchpad bonding curve).");
      if ((mcap || 0) < 10000) add("bad", `Very low market cap (${usd(mcap)}): price is highly sensitive to individual trades.`, 20);
      else if ((mcap || 0) < 50000) add("warn", `Low market cap (${usd(mcap)}): expect high volatility.`, 10);
    } else if (liq < 5000) add("bad", `Very low liquidity (${usd(liq)}): sales may have significant price impact.`, 30);
    else if (liq < 25000) add("warn", `Low liquidity (${usd(liq)}).`, 15);
    else add("good", `Adequate liquidity (${usd(liq)}).`);
    if (isFinite(created)) {
      const ageH = (now - created) / 36e5;
      if (ageH < 24) add("bad", `Recently launched: trading started ${ago(ageH)} ago. New tokens carry elevated risk.`, 15);
      else if (ageH < 168) add("warn", `Early-stage token: trading started ${ago(ageH)} ago.`, 8);
      else add("good", `Trading history: ${ago(ageH)}.`);
    }
    const tx = buys + sells;
    if (tx >= 20 && sells / tx > 0.7) add("warn", `Elevated sell pressure: ${sells} sells vs ${buys} buys in 24h.`, 10);
    else if (tx > 0) add("info", `24h trades: ${buys} buys / ${sells} sells.`);
    if (vol24 < 1000) add("warn", `Very low trading volume (${usd(vol24)} in 24h).`, 10);
  }

  // ----- holders (RugCheck top holders) -----
  const h = holdersFromRugcheck(rc, ps);
  if (h) {
    const note = h.poolPct > 0.5 ? ` (excluding ${h.poolPct.toFixed(1)}% held in pools or bonding curves)` : "";
    if (h.top10 > 50) add("bad", `Top 10 wallets hold ${h.top10.toFixed(1)}% of supply${note}. High concentration increases sell-off risk.`, 30);
    else if (h.top10 > 30) add("warn", `Top 10 wallets hold ${h.top10.toFixed(1)}% of supply${note}. This may include exchange wallets.`, 15);
    else add("good", `Top 10 wallets hold ${h.top10.toFixed(1)}% of supply${note}: broadly distributed.`);
    if (h.top1 > 15) add("warn", `A single wallet holds ${h.top1.toFixed(1)}%.`, 15);
    facts.top10 = h.top10;
  } else add("warn", "Holder data is temporarily unavailable.", 5);

  // ----- RugCheck findings -----
  if (rc) {
    if (rc.rugged) { add("bad", "RugCheck reports this token as rugged.", 50); forceHigh = true; }
    const risks = Array.isArray(rc.risks) ? rc.risks : [];
    risks.filter((r) => r.level === "danger").slice(0, 3)
      .forEach((r) => add("bad", "RugCheck: " + r.name + (r.description ? ` (${r.description})` : ""), 15));
    risks.filter((r) => r.level === "warn").slice(0, 3)
      .forEach((r) => add("info", "RugCheck note: " + r.name + (r.description ? ` (${r.description})` : "")));
  }
  if (rugcheckError) reasons.push(`Note: ${rugcheckError}`);

  const level = forceHigh || pts >= 55 ? "high" : pts >= 25 ? "caution" : "low";
  reasons.unshift(`${LABEL[level]} · risk score ${pts}`);
  return { level, points: pts, reasons, findings, facts };
}
