# BluntX — Token Risk Checker (browser extension, beta)

A Chrome (Manifest V3) extension from [bluntx.fun](https://bluntx.fun). Turn it on for a supported trading or explorer tab and it finds token addresses on the page, rates each coin **Low risk**, **Caution** or **High risk** with a risk score, badges the link, and lists every coin with its findings in an on-page panel and in Chrome's side panel. On any other site, paste an address into the side panel, or select an address and choose **Check with BluntX**.

Version 0.4.0 (beta). Not listed on the Chrome Web Store yet. Scores are automated signals, not guarantees, and not financial advice. BluntX is independent and is not affiliated with the sites it can scan or the data sources it uses.

## Install (load unpacked)

1. Download `bluntx-extension.zip` from https://bluntx.fun/bluntx-extension.zip and unzip it.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped `bluntx-extension` folder.
5. Open a supported site, click the BluntX icon in the toolbar, and switch **On for this tab**.

Works in desktop Chrome and other Chromium browsers that support Manifest V3 extensions.

## Supported sites (auto-scan)

Auto-scan reads token or contract addresses from the page and its URL when you switch the extension on for that tab:

- pump.fun
- Birdeye (birdeye.so and birdeyeterminal.com)
- GMGN (gmgn.ai)
- Photon (photon-sol.tinyastro.io and official Tiny Astro chain domains)
- BullX (bullx.io and neo.bullx.io)
- Axiom (axiom.trade)
- Raydium (raydium.io)
- Jupiter (jup.ag)
- Solscan (solscan.io)
- DexScreener (dexscreener.com)
- Moonshot (moonshot.com)
- letsbonk.fun
- Uniswap (app.uniswap.org)
- Etherscan, BscScan and Basescan
- Four.meme
- DEXTools (dextools.io)
- GeckoTerminal
- CoinGecko token pages, when a contract address is present
- RugCheck (rugcheck.xyz)

On other sites, use the side panel paste box or the context menu on selected text. Auto-scan is not available there.

## How scoring works

Version 0.4.0 runs `core.js`, the exact file the bluntx.fun checker uses, so the extension and the website always give the same rating. Every coin starts at 0 risk points and each finding adds points:

| Risk score | Rating |
|---|---|
| 0–24 | Low risk |
| 25–54 | Caution |
| 55 or more | High risk |

Some findings force High risk: an active freeze authority, a "rugged" flag, a honeypot, a sell tax above 50%, a creator with past rugs or links to scam contracts, linked wallets holding 30% or more, tokens taken from holders' wallets, hidden code that can be swapped, an owner who can edit balances, and Solana permanent-delegate, default-frozen or non-transferable tokens.

The checks cover contract permissions, market data, holders, creator history, linked wallets, and liquidity (main pool, its share of all liquidity, lock % and lock end date). Creator, linked-wallet and liquidity findings have category limits of 40, 35 and 30 points unless a forced finding applies. Every report shows a data confidence (High, Medium or Low) and lists what could not be checked. A Low-confidence report is never shown as Low risk; it shows "Caution: not enough data". Version 0.4.0 also checks for holders with near-identical balances, one wallet funding several holders, sudden price crashes, lookalike token names, upcoming token unlocks, Token-2022 transfer fees and last-hour sell pressure. The side panel shows the risk score with the three main reasons, and all findings folded underneath. The full rule list is on https://bluntx.fun/how.html.

## Data sources

- **DexScreener** `api.dexscreener.com` (batched, up to 20 per call): pools, liquidity, market cap, age, volume, buys/sells, plus one name search per check for lookalike tokens.
- **RugCheck** `api.rugcheck.xyz` (Solana): authorities, top holders, creator history, linked wallets (including the `/insiders/graph` funding map), pool LP locks and lockers. Falls back to `/report/summary` if rate-limited.
- **Solana RPC** (`public.rpc.solanavibestation.com`, `solana-rpc.publicnode.com`): mint/freeze authority and Token-2022 extensions, plus holders when RugCheck has none.
- **GoPlus** `api.gopluslabs.io` (EVM, Tron, Sui): contract permissions, taxes, holders, LP holders and locks, and the creator wallet check.
- **honeypot.is** `api.honeypot.is` (Ethereum, BNB Chain, Base): buy/sell simulation, proxy and holder analysis.
- **Public EVM RPC** (`*-rpc.publicnode.com` for 7 chains): proxy-slot check when GoPlus has no data.

Requests run in the extension's background worker. Results are cached locally for 5 minutes (API responses for 2 minutes). Calls are paced per host: DexScreener at least 1.5 s apart, GoPlus about 2.1 s apart (its free limit is 30 per minute), RugCheck about 1.1 s apart. Auto-scan scores at most 30 addresses on a page, with the address in the current URL first.

## Limits

- The extension reads the page you already have open; it does not call each trading site's private APIs. If a site stops putting the token address in links or in the URL, badges may stop appearing until the scanner is updated.
- Public data can be incomplete, delayed or wrong. A Low risk rating means few known risk signals were found at the time of the check; it is not a guarantee.
- CoinGecko pages often use a slug rather than a contract in the URL. Auto-scan then depends on a contract address being present in a link or labelled field.

## Security

- Manifest V3, no remote code. Extension-page CSP: `script-src 'self'; object-src 'none'; base-uri 'none'; font-src 'self'`, network limited to the APIs listed under Data sources.
- Permissions: `storage` (5-minute cache), `scripting` (adds the badges to a supported tab you switch on), `sidePanel`, and `contextMenus` (Check with BluntX on selected text). Host access is limited to the supported sites listed above, plus the API hosts listed under Data sources.
- Page content and API data are inserted as text, never as HTML.
- Fonts (Fraunces and Inter, SIL Open Font License) are bundled in `fonts/`; nothing is loaded from a font service.

## Privacy

No account, no wallet connection, no transactions, no tracking. Nothing is sent anywhere except the public API lookups above.

## Files

- `manifest.json` — Chrome Manifest V3
- `detect.js` — address detector and per-site URL parsers
- `background.js` — on/off per tab, injection, API cache and rate limits, context menu
- `scoring.js` — scoring rules
- `content.js`, `content.css` — page scanner, badges, on-page list
- `popup.html`, `popup.css`, `popup.js` — on/off for the current tab
- `sidepanel.html`, `sidepanel.css`, `sidepanel.js` — findings list and paste-to-check
- `icons/` — BluntX icons
