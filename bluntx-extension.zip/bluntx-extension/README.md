# BluntX — Token Risk Checker (browser extension, beta)

A Chrome (Manifest V3) extension from [bluntx.fun](https://bluntx.fun). Turn it on for a pump.fun tab and it finds the coin links on the page, rates each coin **Low risk**, **Caution** or **High risk** with a risk score, badges the card, and lists every coin with its findings in an on-page panel and in Chrome's side panel.

Version 0.1.0 (beta). Not listed on the Chrome Web Store yet. Scores are automated signals, not guarantees, and not financial advice.

## Install (load unpacked)

1. Download `bluntx-extension.zip` from https://bluntx.fun/bluntx-extension.zip and unzip it.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped `bluntx-extension` folder.
5. Open [pump.fun](https://pump.fun), click the BluntX icon in the toolbar, and switch **On for this tab**.

Works in desktop Chrome and other Chromium browsers that support Manifest V3 extensions.

## How scoring works

The extension uses the same points model as the Solana checker on bluntx.fun. Every coin starts at 0 risk points and each finding adds points:

| Risk score | Rating |
|---|---|
| 0–24 | Low risk |
| 25–54 | Caution |
| 55 or more | High risk |

Active freeze authority, or a RugCheck "rugged" flag, is High risk automatically.

| Finding | Points |
|---|---|
| Mint authority active | +35 |
| Freeze authority active | +40, automatic High risk |
| Authorities could not be read | +10 |
| No trading market on DexScreener | +25 |
| Liquidity under $5,000 (under $25,000) | +30 (+15) |
| On a bonding curve with market cap under $10,000 (under $50,000) | +20 (+10) |
| Trading started under 24 hours ago (under 7 days) | +15 (+8) |
| More than 70% of 24h trades are sells (min. 20 trades) | +10 |
| 24h volume under $1,000 | +10 |
| Top 10 wallets hold more than 50% (more than 30%), excluding identified pools | +30 (+15) |
| A single wallet holds more than 15% | +15 |
| Holder data unavailable | +5 |
| Each RugCheck "danger" finding (up to 3) | +15 each |

Differences from the website: the extension does not call Solana RPC, so mint/freeze authority and top holders come from the RugCheck report only. Until data arrives, a coin shows **Checking**.

## Data sources

- **DexScreener** `https://api.dexscreener.com/latest/dex/tokens/<mint>[,<mint>…]` (batched, up to 20 mints): liquidity, market cap, age, volume, buys/sells.
- **RugCheck** `https://api.rugcheck.xyz/v1/tokens/<mint>/report`: mint/freeze authority, top holders, pool accounts, risk findings, rugged flag. Falls back to `/report/summary` if rate-limited.

Requests run in the extension's background worker. Results are cached locally in the browser for 5 minutes. DexScreener calls are spaced at least 1.5 s apart and RugCheck calls at least 2 s apart, so a busy board takes a little while to finish.

## Limits

- The extension reads the page you already have open; it does not call pump.fun APIs. If pump.fun stops putting the mint address in coin links (`/coin/<mint>`), badges will stop appearing until the scanner is updated.
- Public data can be incomplete, delayed or wrong. A Low risk rating means few known risk signals were found at the time of the check; it is not a guarantee.

## Security

- Manifest V3, no remote code. Extension-page CSP: `script-src 'self'; object-src 'none'; base-uri 'none'`, network limited to the two APIs below.
- Permissions: `storage` (5-minute cache), `scripting` (adds the badges to a pump.fun tab you switch on) and `sidePanel`. Host access: pump.fun, api.dexscreener.com and api.rugcheck.xyz only.
- Page content and API data are inserted as text, never as HTML.

## Privacy

No account, no wallet connection, no transactions, no tracking. Nothing is sent anywhere except the public API lookups above.

## Files

- `manifest.json` — Chrome Manifest V3
- `background.js` — on/off per tab, injection, API cache and rate limits
- `scoring.js` — scoring rules
- `content.js`, `content.css` — coin scanner, badges, on-page list
- `popup.html`, `popup.css`, `popup.js` — on/off for the current tab
- `sidepanel.html`, `sidepanel.css`, `sidepanel.js` — full findings list
- `icons/` — BluntX icons
