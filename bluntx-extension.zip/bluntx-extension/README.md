# BluntX — Token Risk Checker (browser extension, beta)

A Chrome (Manifest V3) extension from [bluntx.fun](https://bluntx.fun). Turn it on for a supported trading or explorer tab and it finds token addresses on the page, rates each coin **Low risk**, **Caution** or **High risk** with a risk score, badges the link, and lists every coin with its findings in an on-page panel and in Chrome's side panel. On any other site, paste an address into the side panel, or select an address and choose **Check with BluntX**.

Version 0.2.0 (beta). Not listed on the Chrome Web Store yet. Scores are automated signals, not guarantees, and not financial advice. BluntX is independent and is not affiliated with the sites it can scan or the data sources it uses.

## Install (load unpacked)

1. Download `bluntx-extension.zip` from https://bluntx.fun/bluntx-extension.zip and unzip it.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped `bluntx-extension` folder.
5. Open a supported site, click the BluntX icon in the toolbar, and switch **On for this tab**.

Works in desktop Chrome and other Chromium browsers that support Manifest V3 extensions.

## Supported sites (auto-scan)

Auto-scan reads token or contract addresses from the page and its URL when you switch the extension on for that tab:

- pump.fun
- Birdeye (birdeye.so and birdeyeterminal.com)
- GMGN (gmgn.ai)
- Photon (photon-sol.tinyastro.io and official Tiny Astro chain domains)
- BullX (bullx.io and neo.bullx.io)
- Axiom (axiom.trade)
- Raydium (raydium.io)
- Jupiter (jup.ag)
- Solscan (solscan.io)
- DexScreener (dexscreener.com)
- Moonshot (moonshot.com)
- letsbonk.fun
- Uniswap (app.uniswap.org)
- Etherscan, BscScan and Basescan
- Four.meme
- DEXTools (dextools.io)
- GeckoTerminal
- CoinGecko token pages, when a contract address is present
- RugCheck (rugcheck.xyz)

On other sites, use the side panel paste box or the context menu on selected text. Auto-scan is not available there.

## How scoring works

The extension uses the same points model as the Solana checker on bluntx.fun. Every coin starts at 0 risk points and each finding adds points:

| Risk score | Rating |
|---|---|
| 0–24 | Low risk |
| 25–54 | Caution |
| 55 or more | High risk |

Active freeze authority, or a RugCheck "rugged" flag, is High risk automatically.

| Finding | Points |
|---|---|
| Mint authority active | +35 |
| Freeze authority active | +40, automatic High risk |
| Authorities could not be read (Solana) | +10 |
| No trading market on DexScreener | +25 |
| Liquidity under $5,000 (under $25,000) | +30 (+15) |
| On a bonding curve with market cap under $10,000 (under $50,000) | +20 (+10) |
| Trading started under 24 hours ago (under 7 days) | +15 (+8) |
| More than 70% of 24h trades are sells (min. 20 trades) | +10 |
| 24h volume under $1,000 | +10 |
| Top 10 wallets hold more than 50% (more than 30%), excluding identified pools | +30 (+15) |
| A single wallet holds more than 15% | +15 |
| Holder data unavailable (Solana) | +5 |
| Each RugCheck "danger" finding (up to 3) | +15 each |

Mint and freeze authority, holder concentration and RugCheck findings apply to Solana tokens. EVM contracts are scored from DexScreener market data only; those Solana-only checks are skipped and are not penalised. Until data arrives, a coin shows **Checking**.

## Data sources

- **DexScreener** `https://api.dexscreener.com/latest/dex/tokens/<address>[,<address>…]` (batched, up to 20): liquidity, market cap, age, volume, buys/sells. If no token match is found, a search query is used so pair-page addresses can still resolve.
- **RugCheck** `https://api.rugcheck.xyz/v1/tokens/<mint>/report` (Solana only): mint/freeze authority, top holders, pool accounts, risk findings, rugged flag. Falls back to `/report/summary` if rate-limited.

Requests run in the extension's background worker. Results are cached locally in the browser for 5 minutes. DexScreener calls are spaced at least 1.5 s apart and RugCheck calls at least 2 s apart. Auto-scan scores at most 30 addresses on a page, with the address in the current URL first, so a busy board does not exhaust the public RugCheck budget (documented limit: 15 requests).

## Limits

- The extension reads the page you already have open; it does not call each trading site's private APIs. If a site stops putting the token address in links or in the URL, badges may stop appearing until the scanner is updated.
- Public data can be incomplete, delayed or wrong. A Low risk rating means few known risk signals were found at the time of the check; it is not a guarantee.
- CoinGecko pages often use a slug rather than a contract in the URL. Auto-scan then depends on a contract address being present in a link or labelled field.

## Security

- Manifest V3, no remote code. Extension-page CSP: `script-src 'self'; object-src 'none'; base-uri 'none'`, network limited to the two APIs below.
- Permissions: `storage` (5-minute cache), `scripting` (adds the badges to a supported tab you switch on), `sidePanel`, and `contextMenus` (Check with BluntX on selected text). Host access is limited to the supported sites listed above, plus api.dexscreener.com and api.rugcheck.xyz.
- Page content and API data are inserted as text, never as HTML.

## Privacy

No account, no wallet connection, no transactions, no tracking. Nothing is sent anywhere except the public API lookups above.

## Files

- `manifest.json` — Chrome Manifest V3
- `detect.js` — address detector and per-site URL parsers
- `background.js` — on/off per tab, injection, API cache and rate limits, context menu
- `scoring.js` — scoring rules
- `content.js`, `content.css` — page scanner, badges, on-page list
- `popup.html`, `popup.css`, `popup.js` — on/off for the current tab
- `sidepanel.html`, `sidepanel.css`, `sidepanel.js` — findings list and paste-to-check
- `icons/` — BluntX icons
