(() => {
  const EVM_RE = /^0x[a-fA-F0-9]{40}$/;
  const EVM_FIND = /0x[a-fA-F0-9]{40}/g;
  const SOL_FIND = /[1-9A-HJ-NP-Za-km-z]{32,44}/g;
  const BASE58_RE = /^[1-9A-HJ-NP-Za-km-z]+$/;

  const PATH_WORDS = new Set([
    "account", "accounts", "address", "advanced", "analysis", "app", "board",
    "bridge", "chart", "charts", "coin", "coins", "contract", "create", "discover",
    "en", "explore", "explorer", "live", "lp", "market", "markets", "meme", "memes",
    "pair", "pairs", "pool", "pools", "portfolio", "profile", "pulse", "search",
    "sol", "solana", "swap", "terminal", "token", "tokens", "trade", "trades",
    "trending", "wallet", "watchlist"
  ]);

  // Wrapped natives and stablecoins: skip during auto-scan so quote assets do not consume the API budget.
  const SKIP = new Set([
    "So11111111111111111111111111111111111111112",
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    "USD1ttGY1N17NEEHLmELoaybftRJCaskLBKbjWMR",
    "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
    "JuPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
    "27G8MtK7VtTcCHkpASjSDdkWWYfoqT6ggEuKid3m4gPy"
  ]);
  const SKIP_EVM = new Set([
    "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
    "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
    "0xdac17f958d2ee523a2206206994597c13d831ec7",
    "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c",
    "0x4200000000000000000000000000000000000006",
    "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
    "0x0000000000000000000000000000000000000000",
    "0x471ece3750da237f93b8e339c536989b8978a438"
  ]);

  const QUERY_KEYS = new Set([
    "address", "token", "tokenaddress", "token_address", "mint", "contract",
    "ca", "inputmint", "outputmint", "inputcurrency", "outputcurrency",
    "buy", "sell", "currency", "asset"
  ]);

  const SITES = [
    { id: "pump.fun", hosts: ["pump.fun"], patterns: [/\/coin\/(ADDR)/i] },
    { id: "Birdeye", hosts: ["birdeye.so", "birdeyeterminal.com"], patterns: [/\/token\/(ADDR)(?:\/|$|\?)/i] },
    { id: "GMGN", hosts: ["gmgn.ai"], patterns: [/\/(?:sol|eth|base|bsc|monad|tron|arb|op|avax|polygon|blast)\/token\/(?:[A-Za-z0-9]+_)?(ADDR)/i] },
    { id: "Photon", hosts: ["photon-sol.tinyastro.io", "photon.tinyastro.io", "photon-bnb.tinyastro.io", "photon-base.tinyastro.io"], patterns: [/\/(?:[a-z]{2}\/)?lp\/(ADDR)/i] },
    { id: "BullX", hosts: ["neo.bullx.io", "bullx.io"], patterns: [], query: true },
    { id: "Axiom", hosts: ["axiom.trade"], patterns: [/\/(?:t|meme|token)\/(ADDR)/i] },
    { id: "Raydium", hosts: ["raydium.io"], patterns: [], query: true },
    { id: "Jupiter", hosts: ["jup.ag"], patterns: [/\/tokens\/(ADDR)/i, /\/swap\/(?:[^/\s]+-)?(ADDR)/i], query: true },
    { id: "Solscan", hosts: ["solscan.io"], patterns: [/\/(?:token|account)\/(ADDR)/i] },
    { id: "DexScreener", hosts: ["dexscreener.com"], patterns: [/^\/[a-z0-9-]+\/(ADDR)/i] },
    { id: "Moonshot", hosts: ["moonshot.com"], patterns: [/^\/(ADDR)(?:\/|$)/i, /\/(?:token|coins?)\/(ADDR)/i] },
    { id: "letsbonk.fun", hosts: ["letsbonk.fun"], patterns: [/\/token\/(ADDR)/i] },
    { id: "Uniswap", hosts: ["app.uniswap.org"], patterns: [/\/(?:explore\/)?tokens?\/[a-z0-9-]+\/(ADDR)/i], query: true },
    { id: "Etherscan", hosts: ["etherscan.io"], patterns: [/\/token\/(ADDR)/i] },
    { id: "BscScan", hosts: ["bscscan.com"], patterns: [/\/token\/(ADDR)/i] },
    { id: "Basescan", hosts: ["basescan.org"], patterns: [/\/token\/(ADDR)/i] },
    { id: "Four.meme", hosts: ["four.meme"], patterns: [/\/token\/(ADDR)/i] },
    { id: "DEXTools", hosts: ["dextools.io"], patterns: [/\/(?:pair-explorer|token-explorer|token)\/(ADDR)/i] },
    { id: "GeckoTerminal", hosts: ["geckoterminal.com"], patterns: [/\/(?:tokens|pools)\/(ADDR)/i] },
    { id: "CoinGecko", hosts: ["coingecko.com"], patterns: [/\/(?:en\/)?coins\/(?:[a-z0-9-]+\/)?(ADDR)/i] },
    { id: "RugCheck", hosts: ["rugcheck.xyz"], patterns: [/\/tokens\/(ADDR)/i] }
  ];

  const HOST_TO_SITE = new Map();
  for (const site of SITES) {
    for (const host of site.hosts) HOST_TO_SITE.set(host, site);
  }

  const ADDR_TOKEN = "(0x[a-fA-F0-9]{40}|[1-9A-HJ-NP-Za-km-z]{32,44})";

  function compile(pattern) {
    return new RegExp(pattern.source.replace("ADDR", ADDR_TOKEN), pattern.flags);
  }

  function normalizeHost(host) {
    return String(host || "").replace(/^www\./i, "").toLowerCase();
  }

  function isEvmAddress(address) {
    return EVM_RE.test(address || "");
  }

  function isSolAddress(address, { loose = false } = {}) {
    if (!address || isEvmAddress(address)) return false;
    if (!BASE58_RE.test(address)) return false;
    if (address.length < 32 || address.length > 44) return false;
    if (PATH_WORDS.has(address.toLowerCase())) return false;
    if (!loose && address.length < 40) return false;
    return true;
  }

  function isAddress(address, opts) {
    return isEvmAddress(address) || isSolAddress(address, opts);
  }

  function normalizeAddress(address) {
    if (!address) return null;
    return isEvmAddress(address) ? address.toLowerCase() : address;
  }

  function isSkipped(address) {
    if (!address) return false;
    if (isEvmAddress(address)) return SKIP_EVM.has(address.toLowerCase());
    return SKIP.has(address);
  }

  function siteForHost(host) {
    return HOST_TO_SITE.get(normalizeHost(host)) || null;
  }

  function isSupportedHost(host) {
    return HOST_TO_SITE.has(normalizeHost(host));
  }

  function isSupportedUrl(url) {
    try {
      const u = new URL(url);
      return u.protocol === "https:" && isSupportedHost(u.hostname);
    } catch {
      return false;
    }
  }

  function siteNameForUrl(url) {
    try {
      const site = siteForHost(new URL(url).hostname);
      return site ? site.id : null;
    } catch {
      return null;
    }
  }

  function consider(out, seen, value, { loose = true, allowSkip = false } = {}) {
    if (!isAddress(value, { loose })) return;
    if (!allowSkip && isSkipped(value)) return;
    const key = normalizeAddress(value);
    if (seen.has(key)) return;
    seen.add(key);
    out.push(key);
  }

  function extractFromSearchParams(search, out, seen, opts) {
    if (!search) return;
    const params = search instanceof URLSearchParams ? search : new URLSearchParams(String(search).replace(/^\?/, ""));
    for (const [key, value] of params.entries()) {
      if (!QUERY_KEYS.has(key.toLowerCase())) continue;
      if (value === "sol" || value === "eth" || value === "bnb") continue;
      consider(out, seen, value, opts);
    }
  }

  function extractFromUrl(url, opts = {}) {
    const out = [];
    const seen = new Set();
    if (!url) return out;
    let parsed;
    try {
      parsed = new URL(url, opts.base || "https://example.invalid/");
    } catch {
      return out;
    }
    const site = siteForHost(parsed.hostname);
    const pathAndQuery = parsed.pathname + (parsed.search || "");
    if (site) {
      for (const pattern of site.patterns || []) {
        const re = compile(pattern);
        let match;
        const copy = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
        while ((match = copy.exec(pathAndQuery))) {
          consider(out, seen, match[1], { loose: true, allowSkip: opts.allowSkip });
        }
      }
      if (site.query || parsed.search) {
        extractFromSearchParams(parsed.searchParams, out, seen, { loose: true, allowSkip: opts.allowSkip });
      }
    }
    if (!out.length) {
      extractFromSearchParams(parsed.searchParams, out, seen, { loose: true, allowSkip: opts.allowSkip });
      const parts = parsed.pathname.split("/").filter(Boolean);
      for (const part of parts) {
        consider(out, seen, part, { loose: true, allowSkip: opts.allowSkip });
      }
    }
    return out;
  }

  function extractFromText(text, opts = {}) {
    const out = [];
    const seen = new Set();
    const raw = String(text || "").trim();
    if (!raw) return out;
    if (isAddress(raw, { loose: true })) {
      consider(out, seen, raw, { loose: true, allowSkip: true });
      return out;
    }
    try {
      if (/^https?:\/\//i.test(raw) || raw.startsWith("/")) {
        const fromUrl = extractFromUrl(raw, opts);
        if (fromUrl.length) return fromUrl;
      }
    } catch {
      // continue with generic extraction
    }
    const evm = raw.match(EVM_FIND) || [];
    for (const value of evm) consider(out, seen, value, { loose: true, allowSkip: true });
    const sol = raw.match(SOL_FIND) || [];
    for (const value of sol) consider(out, seen, value, { loose: opts.loose !== false, allowSkip: true });
    return out;
  }

  function findAddressesInDocument(doc, pageUrl, { limit = 30 } = {}) {
    const out = [];
    const seen = new Set();
    const addList = (list) => {
      for (const value of list) {
        if (out.length >= limit) return;
        if (seen.has(value)) continue;
        seen.add(value);
        out.push(value);
      }
    };

    addList(extractFromUrl(pageUrl || (doc.defaultView && doc.defaultView.location && doc.defaultView.location.href) || ""));

    const anchors = doc.querySelectorAll("a[href]");
    for (const a of anchors) {
      if (out.length >= limit) break;
      const href = a.getAttribute("href");
      if (!href) continue;
      addList(extractFromUrl(href, { base: pageUrl }));
    }

    const attrNodes = doc.querySelectorAll("[data-address], [data-mint], [data-token], [data-ca], [data-contract], [data-token-address]");
    for (const el of attrNodes) {
      if (out.length >= limit) break;
      for (const attr of ["data-address", "data-mint", "data-token", "data-ca", "data-contract", "data-token-address"]) {
        const value = el.getAttribute(attr);
        if (value) consider(out, seen, value.trim(), { loose: true });
      }
    }

    const codes = doc.querySelectorAll("code, [class*='address' i], [class*='contract' i], [class*='mint' i]");
    for (const el of codes) {
      if (out.length >= limit) break;
      const text = (el.textContent || "").trim();
      if (isAddress(text, { loose: true })) consider(out, seen, text, { loose: true });
    }

    return out.map((address) => {
      const el = findElementForAddress(doc, address, pageUrl);
      return { address, el };
    });
  }

  function findElementForAddress(doc, address, pageUrl) {
    const evm = isEvmAddress(address);
    const needle = evm ? address.toLowerCase() : address;
    for (const a of doc.querySelectorAll("a[href]")) {
      const href = a.getAttribute("href") || "";
      const found = extractFromUrl(href, { base: pageUrl, allowSkip: true });
      if (found.includes(needle) || href.includes(address) || (evm && href.toLowerCase().includes(needle))) {
        return a;
      }
    }
    return null;
  }

  function explorerUrl(address) {
    return isEvmAddress(address)
      ? "https://dexscreener.com/search?q=" + encodeURIComponent(address)
      : "https://dexscreener.com/solana/" + encodeURIComponent(address);
  }

  const api = {
    SITES,
    SKIP,
    isEvmAddress,
    isSolAddress,
    isAddress,
    isSkipped,
    normalizeAddress,
    normalizeHost,
    isSupportedHost,
    isSupportedUrl,
    siteNameForUrl,
    extractFromUrl,
    extractFromText,
    findAddressesInDocument,
    explorerUrl
  };

  if (typeof globalThis !== "undefined") globalThis.BluntXDetect = api;
})();
