const statusEl = document.getElementById("status");
const toggle = document.getElementById("toggle");
const wrap = document.getElementById("toggle-wrap");
const errorEl = document.getElementById("error");

function setError(msg) {
  if (!msg) {
    errorEl.hidden = true;
    errorEl.textContent = "";
    return;
  }
  errorEl.hidden = false;
  errorEl.textContent = msg;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function refresh() {
  setError("");
  const tab = await activeTab();
  if (!tab?.id) {
    statusEl.textContent = "No active tab.";
    wrap.hidden = true;
    return;
  }
  const res = await chrome.runtime.sendMessage({ type: "BX_GET_STATUS", tabId: tab.id });
  if (!res?.ok) {
    statusEl.textContent = "Could not reach BluntX.";
    wrap.hidden = true;
    return;
  }
  if (!res.isPump) {
    statusEl.className = "status warn";
    statusEl.textContent = "Open a pump.fun tab to turn BluntX on.";
    wrap.hidden = true;
    toggle.checked = false;
    return;
  }
  wrap.hidden = false;
  toggle.checked = !!res.enabled;
  statusEl.className = "status ok";
  statusEl.textContent = res.enabled
    ? "On for this pump.fun tab. Coins on the page will be scored."
    : "This is a pump.fun tab. Switch BluntX on to scan it.";
}

toggle.addEventListener("change", async () => {
  setError("");
  const tab = await activeTab();
  try {
    const res = await chrome.runtime.sendMessage({
      type: "BX_SET_ENABLED",
      tabId: tab.id,
      enabled: toggle.checked
    });
    if (!res?.ok) throw new Error(res?.error || "Toggle failed");
    if (toggle.checked && chrome.sidePanel?.open) {
      try {
        await chrome.sidePanel.open({ tabId: tab.id });
      } catch {
        // Side panel may be unavailable; the in-page overlay still works.
      }
    }
    await refresh();
  } catch (err) {
    toggle.checked = !toggle.checked;
    setError(err.message || String(err));
  }
});

refresh();
