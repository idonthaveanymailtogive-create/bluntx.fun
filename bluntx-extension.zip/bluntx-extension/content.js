(() => {
  const detect = globalThis.BluntXDetect;
  if (!detect) return;

  if (window.__BLUNTX__) {
    window.__BLUNTX__.enable();
    return;
  }

  const LABELS = { low: "Low risk", caution: "Caution", high: "High risk" };
  const MAX_PAGE = 30;

  function LEVEL_LABEL(level, score) {
    if (!LABELS[level]) return "Checking…";
    return score && typeof score.points === "number" ? `${LABELS[level]} · ${score.points}` : LABELS[level];
  }

  const state = {
    enabled: true,
    coins: new Map(),
    pending: new Set(),
    observer: null,
    scanTimer: null,
    overlay: null,
    lastUrl: location.href
  };

  function reasonsText(score) {
    const lines = (score?.reasons || []).filter(Boolean);
    return lines.length ? lines.join("\n") : "No reasons yet.";
  }

  function placeBadge(anchor, address, score) {
    if (!anchor) return;
    let badge = anchor.querySelector(`:scope > .bx-badge[data-bx-mint="${CSS.escape(address)}"]`);
    if (!badge) {
      badge = document.createElement("span");
      badge.className = "bx-badge";
      badge.dataset.bxMint = address;
      badge.setAttribute("role", "note");
      const cs = getComputedStyle(anchor);
      if (cs.position === "static" && anchor.offsetHeight >= 56) {
        anchor.classList.add("bx-badge-host");
        badge.classList.add("bx-badge--corner");
      }
      anchor.appendChild(badge);
    }
    const level = score?.level || "unknown";
    badge.dataset.level = level;
    badge.textContent = LEVEL_LABEL(level, score);
    badge.title = reasonsText(score);
    badge.setAttribute("aria-label", `BluntX: ${badge.textContent}. ${reasonsText(score)}`);
  }

  function renderOverlay() {
    if (!state.enabled) return;
    if (!state.overlay) {
      const root = document.createElement("aside");
      root.id = "bx-overlay";
      const head = mk("div", { class: "bx-overlay-head" }, [
        mk("strong", null, ["Blunt", mk("b", { text: "X" })]),
        mk("button", { type: "button", class: "bx-overlay-toggle", "aria-label": "Collapse BluntX list", text: "Hide" })
      ]);
      root.append(head, mk("p", { class: "bx-overlay-sub", text: "Coins on this page" }), mk("ul", { class: "bx-overlay-list" }));
      root.querySelector(".bx-overlay-toggle").addEventListener("click", () => {
        root.classList.toggle("bx-collapsed");
        const collapsed = root.classList.contains("bx-collapsed");
        root.querySelector(".bx-overlay-toggle").textContent = collapsed ? "Show" : "Hide";
      });
      document.documentElement.appendChild(root);
      state.overlay = root;
    }
    const list = state.overlay.querySelector(".bx-overlay-list");
    const entries = [...state.coins.entries()].sort((a, b) => {
      const rank = { high: 0, caution: 1, unknown: 2, low: 3 };
      return (rank[a[1]?.level] ?? 9) - (rank[b[1]?.level] ?? 9);
    });
    list.replaceChildren();
    if (!entries.length) {
      const li = document.createElement("li");
      li.className = "bx-empty";
      li.textContent = "No token addresses found yet on this page.";
      list.appendChild(li);
      return;
    }
    for (const [address, score] of entries) {
      const level = score?.level || "unknown";
      const name = score?.facts?.symbol || score?.facts?.name || address.slice(0, 6);
      const safeLevel = LABELS[level] ? level : "unknown";
      const href = detect.explorerUrl(address);
      const short = address.length > 12 ? address.slice(0, 4) + "…" + address.slice(-4) : address;
      const link = mk("a", { href, target: "_blank", rel: "noopener noreferrer" }, [
        mk("span", { class: "bx-name", text: String(name) }),
        mk("span", { class: "bx-mint", text: short })
      ]);
      const li = document.createElement("li");
      li.append(mk("span", { class: "bx-badge", "data-level": safeLevel, text: LEVEL_LABEL(level, score) }), link);
      li.title = reasonsText(score);
      list.appendChild(li);
    }
  }

  function mk(tag, attrs, kids) {
    const n = document.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) {
      if (k === "class") n.className = attrs[k]; else if (k === "text") n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]);
    }
    for (const c of kids || []) n.append(c);
    return n;
  }

  function publish() {
    const coins = {};
    for (const [mint, score] of state.coins) coins[mint] = score;
    renderOverlay();
    chrome.runtime.sendMessage({ type: "BX_COINS_UPDATED", coins }).catch(() => {});
  }

  async function requestScores(mints) {
    const wait = [];
    for (const mint of mints) {
      if (state.pending.has(mint)) continue;
      const existing = state.coins.get(mint);
      if (existing && existing.level !== "unknown") continue;
      state.pending.add(mint);
      if (!existing) {
        state.coins.set(mint, { level: "unknown", reasons: ["Checking public data…"], facts: { mint } });
      }
      wait.push(mint);
    }
    if (wait.length) publish();
    if (!wait.length) return;
    try {
      const res = await chrome.runtime.sendMessage({ type: "BX_SCORE_MINTS", mints: wait });
      const scores = res?.scores || {};
      for (const mint of wait) {
        if (scores[mint]) state.coins.set(mint, scores[mint]);
        state.pending.delete(mint);
      }
    } catch (err) {
      for (const mint of wait) {
        state.pending.delete(mint);
        if (!state.coins.get(mint) || state.coins.get(mint).level === "unknown") {
          state.coins.set(mint, {
            level: "unknown",
            reasons: [`Could not reach the extension background: ${err.message || err}`],
            facts: { mint }
          });
        }
      }
    }
    publish();
  }

  function decorate() {
    if (!state.enabled) return;
    const pageUrl = location.href;
    if (pageUrl !== state.lastUrl) {
      state.lastUrl = pageUrl;
      // Drop prior page results so a SPA navigation does not keep stale coins.
      state.coins.clear();
    }
    const found = detect.findAddressesInDocument(document, pageUrl, { limit: MAX_PAGE });
    const mints = [];
    for (const { address, el } of found) {
      mints.push(address);
      placeBadge(el, address, state.coins.get(address));
    }
    requestScores([...new Set(mints)]);
  }

  function scheduleScan() {
    if (!state.enabled) return;
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(decorate, 250);
  }

  function startObserver() {
    if (state.observer) return;
    state.observer = new MutationObserver(() => scheduleScan());
    state.observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function stopObserver() {
    state.observer?.disconnect();
    state.observer = null;
  }

  function hookHistory() {
    if (window.__BLUNTX_HISTORY__) return;
    window.__BLUNTX_HISTORY__ = true;
    const wrap = (fn) => function () {
      const ret = fn.apply(this, arguments);
      scheduleScan();
      return ret;
    };
    try {
      history.pushState = wrap(history.pushState);
      history.replaceState = wrap(history.replaceState);
    } catch {
      // some sites freeze history methods
    }
    window.addEventListener("popstate", scheduleScan);
    window.addEventListener("hashchange", scheduleScan);
  }

  function enable() {
    state.enabled = true;
    document.documentElement.classList.add("bx-on");
    hookHistory();
    startObserver();
    decorate();
    renderOverlay();
  }

  function disable() {
    state.enabled = false;
    stopObserver();
    document.documentElement.classList.remove("bx-on");
    document.querySelectorAll(".bx-badge").forEach((el) => el.remove());
    document.querySelectorAll(".bx-badge-host").forEach((el) => el.classList.remove("bx-badge-host"));
    state.overlay?.remove();
    state.overlay = null;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "BX_ENABLE") {
      enable();
      sendResponse({ ok: true });
    } else if (message?.type === "BX_DISABLE") {
      disable();
      sendResponse({ ok: true });
    } else if (message?.type === "BX_GET_PAGE_COINS") {
      const coins = {};
      for (const [mint, score] of state.coins) coins[mint] = score;
      sendResponse({ ok: true, coins });
    }
    return false;
  });

  window.__BLUNTX__ = { enable, disable };
  enable();
})();
