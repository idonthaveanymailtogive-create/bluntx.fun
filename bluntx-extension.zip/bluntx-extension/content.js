(() => {
  if (window.__BLUNTX__) {
    window.__BLUNTX__.enable();
    return;
  }

  const MINT_RE = /[1-9A-HJ-NP-Za-km-z]{32,44}/;
  const COIN_PATH = /(?:https?:\/\/(?:www\.)?pump\.fun)?\/(?:coin\/)?([1-9A-HJ-NP-Za-km-z]{32,44})(?:\/|\?|#|$)/i;
  const SKIP = new Set([
    "So11111111111111111111111111111111111111112",
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    "USD1ttGY1N17NEEHLmELoaybftRJCaskLBKbjWMR",
    "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
  ]);

  const LABELS = { low: "Low risk", caution: "Caution", high: "High risk" };
  function LEVEL_LABEL(level, score) {
    if (!LABELS[level]) return "Checking…";
    return score && typeof score.points === "number" ? `${LABELS[level]} · ${score.points}` : LABELS[level];
  }

  const state = {
    enabled: true,
    coins: new Map(),
    pending: new Set(),
    observer: null,
    scanTimer: null,
    overlay: null
  };

  function extractMint(href) {
    if (!href) return null;
    let url = href;
    try {
      url = new URL(href, location.href).pathname + (new URL(href, location.href).search || "");
    } catch {
      // use raw href
    }
    const match = href.match(COIN_PATH) || url.match(COIN_PATH);
    if (!match) return null;
    const mint = match[1];
    if (!MINT_RE.test(mint) || SKIP.has(mint)) return null;
    if (/^(profile|board|create|live|coin)$/i.test(mint)) return null;
    return mint;
  }

  function findCoinLinks() {
    const found = [];
    const seenEl = new Set();
    for (const a of document.querySelectorAll("a[href]")) {
      const mint = extractMint(a.getAttribute("href"));
      if (!mint || seenEl.has(a)) continue;
      seenEl.add(a);
      found.push({ mint, el: a });
    }
    return found;
  }

  function reasonsText(score) {
    const lines = (score?.reasons || []).filter(Boolean);
    return lines.length ? lines.join("\n") : "No reasons yet.";
  }

  function placeBadge(anchor, mint, score) {
    let badge = anchor.querySelector(`:scope > .bx-badge[data-bx-mint="${CSS.escape(mint)}"]`);
    if (!badge) {
      badge = document.createElement("span");
      badge.className = "bx-badge";
      badge.dataset.bxMint = mint;
      badge.setAttribute("role", "note");
      const cs = getComputedStyle(anchor);
      if (cs.position === "static" && anchor.offsetHeight >= 56) {
        anchor.classList.add("bx-badge-host");
        badge.classList.add("bx-badge--corner");
      }
      anchor.appendChild(badge);
    }
    const level = score?.level || "unknown";
    badge.dataset.level = level;
    badge.textContent = LEVEL_LABEL(level, score);
    badge.title = reasonsText(score);
    badge.setAttribute("aria-label", `BluntX: ${badge.textContent}. ${reasonsText(score)}`);
  }

  function renderOverlay() {
    if (!state.enabled) return;
    if (!state.overlay) {
      const root = document.createElement("aside");
      root.id = "bx-overlay";
      const head = mk("div", { class: "bx-overlay-head" }, [
        mk("strong", null, ["Blunt", mk("b", { text: "X" })]),
        mk("button", { type: "button", class: "bx-overlay-toggle", "aria-label": "Collapse BluntX list", text: "Hide" })
      ]);
      root.append(head, mk("p", { class: "bx-overlay-sub", text: "Coins on this page" }), mk("ul", { class: "bx-overlay-list" }));
      root.querySelector(".bx-overlay-toggle").addEventListener("click", () => {
        root.classList.toggle("bx-collapsed");
        const collapsed = root.classList.contains("bx-collapsed");
        root.querySelector(".bx-overlay-toggle").textContent = collapsed ? "Show" : "Hide";
      });
      document.documentElement.appendChild(root);
      state.overlay = root;
    }
    const list = state.overlay.querySelector(".bx-overlay-list");
    const entries = [...state.coins.entries()].sort((a, b) => {
      const rank = { high: 0, caution: 1, unknown: 2, low: 3 };
      return (rank[a[1]?.level] ?? 9) - (rank[b[1]?.level] ?? 9);
    });
    list.replaceChildren();
    if (!entries.length) {
      const li = document.createElement("li");
      li.className = "bx-empty";
      li.textContent = "No coin links found yet on this page.";
      list.appendChild(li);
      return;
    }
    for (const [mint, score] of entries) {
      const li = document.createElement("li");
      const level = score?.level || "unknown";
      const name = score?.facts?.symbol || score?.facts?.name || mint.slice(0, 6);
      const safeLevel = LABELS[level] ? level : "unknown";
      const link = mk("a", { href: "https://pump.fun/coin/" + encodeURIComponent(mint), target: "_blank", rel: "noopener noreferrer" }, [
        mk("span", { class: "bx-name", text: String(name) }),
        mk("span", { class: "bx-mint", text: mint.slice(0, 4) + "…" + mint.slice(-4) })
      ]);
      li.append(mk("span", { class: "bx-badge", "data-level": safeLevel, text: LEVEL_LABEL(level, score) }), link);
      li.title = reasonsText(score);
      list.appendChild(li);
    }
  }

  function mk(tag, attrs, kids) {
    const n = document.createElement(tag);
    if (attrs) for (const k of Object.keys(attrs)) {
      if (k === "class") n.className = attrs[k]; else if (k === "text") n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]);
    }
    for (const c of kids || []) n.append(c);
    return n;
  }


  function publish() {
    const coins = {};
    for (const [mint, score] of state.coins) coins[mint] = score;
    renderOverlay();
    chrome.runtime.sendMessage({ type: "BX_COINS_UPDATED", coins }).catch(() => {});
  }

  async function requestScores(mints) {
    const wait = [];
    for (const mint of mints) {
      if (state.pending.has(mint)) continue;
      const existing = state.coins.get(mint);
      if (existing && existing.level !== "unknown") continue;
      state.pending.add(mint);
      if (!existing) {
        state.coins.set(mint, { level: "unknown", reasons: ["Checking public data…"], facts: { mint } });
      }
      wait.push(mint);
    }
    if (wait.length) publish();
    if (!wait.length) return;
    try {
      const res = await chrome.runtime.sendMessage({ type: "BX_SCORE_MINTS", mints: wait });
      const scores = res?.scores || {};
      for (const mint of wait) {
        if (scores[mint]) state.coins.set(mint, scores[mint]);
        state.pending.delete(mint);
      }
    } catch (err) {
      for (const mint of wait) {
        state.pending.delete(mint);
        if (!state.coins.get(mint) || state.coins.get(mint).level === "unknown") {
          state.coins.set(mint, {
            level: "unknown",
            reasons: [`Could not reach the extension background: ${err.message || err}`],
            facts: { mint }
          });
        }
      }
    }
    publish();
  }

  function decorate() {
    if (!state.enabled) return;
    const links = findCoinLinks();
    const mints = [];
    for (const { mint, el } of links) {
      mints.push(mint);
      placeBadge(el, mint, state.coins.get(mint));
    }
    requestScores([...new Set(mints)]);
  }

  function scheduleScan() {
    if (!state.enabled) return;
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(decorate, 250);
  }

  function startObserver() {
    if (state.observer) return;
    state.observer = new MutationObserver(() => scheduleScan());
    state.observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function stopObserver() {
    state.observer?.disconnect();
    state.observer = null;
  }

  function enable() {
    state.enabled = true;
    document.documentElement.classList.add("bx-on");
    startObserver();
    decorate();
    renderOverlay();
  }

  function disable() {
    state.enabled = false;
    stopObserver();
    document.documentElement.classList.remove("bx-on");
    document.querySelectorAll(".bx-badge").forEach((el) => el.remove());
    document.querySelectorAll(".bx-badge-host").forEach((el) => el.classList.remove("bx-badge-host"));
    state.overlay?.remove();
    state.overlay = null;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "BX_ENABLE") {
      enable();
      sendResponse({ ok: true });
    } else if (message?.type === "BX_DISABLE") {
      disable();
      sendResponse({ ok: true });
    } else if (message?.type === "BX_GET_PAGE_COINS") {
      const coins = {};
      for (const [mint, score] of state.coins) coins[mint] = score;
      sendResponse({ ok: true, coins });
    }
    return false;
  });

  window.__BLUNTX__ = { enable, disable };
  enable();
})();
