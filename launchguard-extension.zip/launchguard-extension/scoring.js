// Scoring rules are documented in README.md. Only real API fields are used.

const DANGER_LEVELS = new Set(["danger", "critical", "rugged"]);
const WARN_LEVELS = new Set(["warn", "warning"]);
const RUG_NAME = /honeypot|rug pull|rugged|liquidity.?removed|lp.?removed|stolen/;
const MINT_FREEZE_NAME = /mint authority|freeze authority/;
const HOLDER_NAME = /holder concentration|single holder|top.?10/;

export function normalizeRugcheck(report) {
  if (!report || typeof report !== "object") return report;
  if (typeof report.lpLockedPct === "number") return report;
  const markets = Array.isArray(report.markets) ? report.markets : [];
  let bestPct = null;
  let bestLiq = -1;
  for (const market of markets) {
    const pct = market?.lp?.lpLockedPct;
    if (typeof pct !== "number") continue;
    const liq = Number(market?.lp?.lpLockedUSD ?? market?.lp?.quoteUSD ?? 0);
    if (liq >= bestLiq) {
      bestLiq = liq;
      bestPct = pct;
    }
  }
  if (bestPct == null) return report;
  return { ...report, lpLockedPct: bestPct };
}

export function pickBestPair(pairs, mint) {
  if (!Array.isArray(pairs) || !pairs.length) return null;
  const wanted = (pairs || []).filter((p) => {
    const base = p?.baseToken?.address;
    const quote = p?.quoteToken?.address;
    return base === mint || quote === mint;
  });
  const list = wanted.length ? wanted : [];
  if (!list.length) return null;
  list.sort((a, b) => {
    const la = a?.liquidity?.usd ?? -1;
    const lb = b?.liquidity?.usd ?? -1;
    return lb - la;
  });
  return list[0];
}

function fmtUsd(n) {
  if (typeof n !== "number" || !Number.isFinite(n)) return null;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}k`;
  return `$${n.toFixed(0)}`;
}

function formatAge(ts) {
  if (typeof ts !== "number" || !Number.isFinite(ts)) return null;
  const ms = Date.now() - ts;
  if (ms < 0) return "just now";
  const m = Math.floor(ms / 60000);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function shortAddr(addr) {
  if (!addr || typeof addr !== "string") return "";
  return addr.length <= 10 ? addr : `${addr.slice(0, 4)}…${addr.slice(-4)}`;
}

function riskText(risk) {
  const name = risk?.name || "Risk flag";
  const value = risk?.value ? ` (${risk.value})` : "";
  const desc = risk?.description ? `: ${risk.description}` : "";
  return `${name}${value}${desc}`;
}

function escalate(current, next) {
  const rank = { unknown: 0, safe: 1, risky: 2, rug: 3 };
  return (rank[next] || 0) >= (rank[current] || 0) ? next : current;
}

export function scoreToken({ mint, rugcheck, pair, rugcheckError, dexError }) {
  const reasons = [];
  const facts = {
    mint,
    name: pair?.baseToken?.name || rugcheck?.tokenMeta?.name || rugcheck?.fileMeta?.name || null,
    symbol: pair?.baseToken?.symbol || rugcheck?.tokenMeta?.symbol || rugcheck?.fileMeta?.symbol || null,
    dexId: pair?.dexId || null,
    liquidityUsd: typeof pair?.liquidity?.usd === "number" ? pair.liquidity.usd : null,
    volumeH24: typeof pair?.volume?.h24 === "number" ? pair.volume.h24 : null,
    marketCap: typeof pair?.marketCap === "number" ? pair.marketCap : (typeof pair?.fdv === "number" ? pair.fdv : null),
    pairCreatedAt: typeof pair?.pairCreatedAt === "number" ? pair.pairCreatedAt : null,
    socials: Array.isArray(pair?.info?.socials) ? pair.info.socials : [],
    websites: Array.isArray(pair?.info?.websites) ? pair.info.websites : [],
    lpLockedPct: typeof rugcheck?.lpLockedPct === "number" ? rugcheck.lpLockedPct : null,
    scoreNormalised: typeof rugcheck?.score_normalised === "number" ? rugcheck.score_normalised : null,
    mintAuthority: rugcheck?.mintAuthority ?? rugcheck?.token?.mintAuthority ?? null,
    freezeAuthority: rugcheck?.freezeAuthority ?? rugcheck?.token?.freezeAuthority ?? null,
    rugged: rugcheck?.rugged === true
  };

  let level = "unknown";

  if (!rugcheck && !pair) {
    if (rugcheckError || dexError) {
      reasons.push("No data yet from DexScreener or RugCheck.");
      if (rugcheckError) reasons.push(`RugCheck: ${rugcheckError}`);
      if (dexError) reasons.push(`DexScreener: ${dexError}`);
    } else {
      reasons.push("Waiting for public market and safety data.");
    }
    return { level: "unknown", reasons, facts };
  }

  if (facts.rugged) {
    level = escalate(level, "rug");
    reasons.push("RugCheck marked this token as rugged.");
  }

  const risks = Array.isArray(rugcheck?.risks) ? rugcheck.risks : [];
  for (const risk of risks) {
    reasons.push(riskText(risk));
    const lv = String(risk?.level || "").toLowerCase();
    const name = String(risk?.name || "").toLowerCase();
    if (DANGER_LEVELS.has(lv) || RUG_NAME.test(name)) {
      level = escalate(level, "rug");
    } else if (WARN_LEVELS.has(lv) || MINT_FREEZE_NAME.test(name) || HOLDER_NAME.test(name)) {
      level = escalate(level, "risky");
    }
  }

  if (facts.mintAuthority) {
    level = escalate(level, "risky");
    reasons.push(`Mint authority is still active (${shortAddr(facts.mintAuthority)}).`);
  } else if (rugcheck && facts.mintAuthority === null) {
    reasons.push("Mint authority is revoked (null).");
  }

  if (facts.freezeAuthority) {
    level = escalate(level, "risky");
    reasons.push(`Freeze authority is still active (${shortAddr(facts.freezeAuthority)}).`);
  } else if (rugcheck && facts.freezeAuthority === null) {
    reasons.push("Freeze authority is revoked (null).");
  }

  if (typeof facts.lpLockedPct === "number") {
    const pct = facts.lpLockedPct;
    if (pct >= 90) {
      reasons.push(`Liquidity lock reported at ${pct.toFixed(1)}%.`);
    } else if (pct <= 0 && facts.dexId && facts.dexId !== "pumpfun") {
      level = escalate(level, "risky");
      reasons.push("Reported liquidity lock is 0% after leaving the pump.fun curve.");
    } else if (pct > 0 && pct < 90 && facts.dexId && facts.dexId !== "pumpfun") {
      level = escalate(level, "risky");
      reasons.push(`Only ${pct.toFixed(1)}% of liquidity is reported locked.`);
    } else if (facts.dexId === "pumpfun" && pct <= 0) {
      reasons.push("Still on the pump.fun curve; no LP lock reported yet (normal for unmigrated coins).");
    } else {
      reasons.push(`Liquidity lock reported at ${pct.toFixed(1)}%.`);
    }
  }

  if (typeof facts.liquidityUsd === "number") {
    reasons.push(`Liquidity about ${fmtUsd(facts.liquidityUsd)} on ${facts.dexId || "DexScreener"}.`);
  } else if (facts.dexId === "pumpfun") {
    reasons.push("Still on pump.fun; DexScreener does not list a liquidity pool yet.");
  }

  if (typeof facts.marketCap === "number") {
    reasons.push(`Market cap about ${fmtUsd(facts.marketCap)}.`);
  }
  if (typeof facts.volumeH24 === "number") {
    reasons.push(`24h volume about ${fmtUsd(facts.volumeH24)}.`);
  }
  const age = formatAge(facts.pairCreatedAt);
  if (age) reasons.push(`Pair created ${age}.`);

  const linkCount = facts.socials.length + facts.websites.length;
  if (linkCount > 0) {
    reasons.push(`DexScreener lists ${linkCount} social or website link(s).`);
  } else if (pair) {
    reasons.push("DexScreener lists no socials or website for this pair.");
  }

  if (rugcheck && level === "unknown") {
    // A successful RugCheck report with no danger/warn flags is Safe.
    level = "safe";
    if (!risks.length) reasons.unshift("RugCheck reported no risk flags.");
  } else if (!rugcheck) {
    reasons.unshift("RugCheck data is not available yet, so no Safe/Risky/Rug score is assigned.");
    level = "unknown";
  }

  if (rugcheckError && !rugcheck) {
    reasons.push(`RugCheck: ${rugcheckError}`);
  }
  if (dexError && !pair) {
    reasons.push(`DexScreener: ${dexError}`);
  }

  return { level, reasons, facts };
}

export const LABEL = {
  safe: "Safe",
  risky: "Risky",
  rug: "Rug",
  unknown: "Checking"
};
