import { pickBestPair, scoreToken, normalizeRugcheck } from "./scoring.js";

const CACHE_TTL_MS = 5 * 60 * 1000;
const DEX_INTERVAL_MS = 1500;
const RUG_INTERVAL_MS = 2000;
const DEX_BATCH_SIZE = 20;
const CACHE_PREFIX = "lg_cache_v1_";

const tabEnabled = new Map();
const tabCoins = new Map(); // tabId -> { mint: result }

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function isPumpUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && (u.hostname === "pump.fun" || u.hostname === "www.pump.fun");
  } catch {
    return false;
  }
}

class RateLimiter {
  constructor(minIntervalMs) {
    this.minIntervalMs = minIntervalMs;
    this.queue = [];
    this.running = false;
    this.nextAt = 0;
  }
  enqueue(fn) {
    return new Promise((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
      this.drain();
    });
  }
  async drain() {
    if (this.running) return;
    this.running = true;
    while (this.queue.length) {
      const wait = this.nextAt - Date.now();
      if (wait > 0) await sleep(wait);
      const job = this.queue.shift();
      try {
        const result = await job.fn();
        this.nextAt = Date.now() + this.minIntervalMs;
        job.resolve(result);
      } catch (err) {
        this.nextAt = Date.now() + this.minIntervalMs;
        job.reject(err);
      }
    }
    this.running = false;
  }
}

const dexLimiter = new RateLimiter(DEX_INTERVAL_MS);
const rugLimiter = new RateLimiter(RUG_INTERVAL_MS);

const memoryCache = new Map();
const dexPending = new Map(); // mint -> Promise
const rugPending = new Map();
let dexBatchQueue = new Set();
let dexBatchWaiters = new Map();
let dexBatchTimer = null;

async function cacheGet(mint) {
  const mem = memoryCache.get(mint);
  if (mem && Date.now() - mem.cachedAt < CACHE_TTL_MS) return mem;
  try {
    const key = CACHE_PREFIX + mint;
    const stored = await chrome.storage.local.get(key);
    const row = stored[key];
    if (row && Date.now() - row.cachedAt < CACHE_TTL_MS) {
      memoryCache.set(mint, row);
      return row;
    }
  } catch {
    // storage can fail in tests; ignore
  }
  return null;
}

async function cacheSet(mint, row) {
  const packed = { ...row, cachedAt: Date.now() };
  memoryCache.set(mint, packed);
  try {
    await chrome.storage.local.set({ [CACHE_PREFIX + mint]: packed });
  } catch {
    // ignore
  }
  return packed;
}

async function fetchJson(url, timeoutMs = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { accept: "application/json" }
    });
    const text = await res.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 200) };
    }
    return { ok: res.ok, status: res.status, headers: res.headers, body };
  } finally {
    clearTimeout(t);
  }
}

function scheduleDexBatch() {
  if (dexBatchTimer) return;
  dexBatchTimer = setTimeout(flushDexBatch, 250);
}

async function flushDexBatch() {
  dexBatchTimer = null;
  const mints = [...dexBatchQueue].slice(0, DEX_BATCH_SIZE);
  mints.forEach((m) => dexBatchQueue.delete(m));
  if (!mints.length) return;
  const waiters = mints.map((m) => [m, dexBatchWaiters.get(m)]).filter((x) => x[1]);
  mints.forEach((m) => dexBatchWaiters.delete(m));

  try {
    const result = await dexLimiter.enqueue(async () => {
      const url = `https://api.dexscreener.com/latest/dex/tokens/${mints.join(",")}`;
      const res = await fetchJson(url);
      if (res.status === 429) {
        await sleep(4000);
        throw new Error("DexScreener rate-limited (HTTP 429)");
      }
      if (!res.ok) throw new Error(`DexScreener HTTP ${res.status}`);
      return res.body;
    });
    const pairs = Array.isArray(result?.pairs) ? result.pairs : [];
    for (const [mint, deferred] of waiters) {
      deferred.resolve({ pairs, error: null });
    }
  } catch (err) {
    for (const [, deferred] of waiters) {
      deferred.resolve({ pairs: [], error: String(err.message || err) });
    }
  }

  if (dexBatchQueue.size) scheduleDexBatch();
}

function requestDex(mint) {
  if (dexPending.has(mint)) return dexPending.get(mint);
  const promise = new Promise((resolve) => {
    dexBatchWaiters.set(mint, { resolve });
    dexBatchQueue.add(mint);
    scheduleDexBatch();
  });
  dexPending.set(mint, promise);
  promise.finally(() => dexPending.delete(mint));
  return promise;
}

function requestRug(mint) {
  if (rugPending.has(mint)) return rugPending.get(mint);
  const promise = rugLimiter.enqueue(async () => {
    const url = `https://api.rugcheck.xyz/v1/tokens/${encodeURIComponent(mint)}/report`;
    let res = await fetchJson(url, 20000);
    if (res.status === 429) {
      await sleep(8000);
      res = await fetchJson(url, 20000);
    }
    if (res.status === 429) {
      // Fall back to the lighter summary if the full report is throttled.
      const summary = await fetchJson(
        `https://api.rugcheck.xyz/v1/tokens/${encodeURIComponent(mint)}/report/summary`,
        15000
      );
      if (summary.ok) return { report: summary.body, error: "Full report rate-limited; used summary instead." };
      throw new Error("RugCheck rate-limited (HTTP 429). The public API header is x-rate-limit-limit: 15.");
    }
    if (!res.ok) throw new Error(`RugCheck HTTP ${res.status}`);
    return { report: res.body, error: null };
  });
  rugPending.set(mint, promise);
  promise.finally(() => rugPending.delete(mint));
  return promise;
}

async function scoreMint(mint, { force = false } = {}) {
  if (!force) {
    const cached = await cacheGet(mint);
    if (cached?.score) return cached;
  }

  let pair = null;
  let rugcheck = null;
  let dexError = null;
  let rugcheckError = null;

  const [dexRes, rugRes] = await Promise.allSettled([requestDex(mint), requestRug(mint)]);

  if (dexRes.status === "fulfilled") {
    pair = pickBestPair(dexRes.value.pairs, mint);
    dexError = dexRes.value.error;
    if (!pair && !dexError) dexError = "No DexScreener pair found for this mint.";
  } else {
    dexError = String(dexRes.reason?.message || dexRes.reason);
  }

  if (rugRes.status === "fulfilled") {
    rugcheck = rugRes.value.report;
    rugcheckError = rugRes.value.error;
  } else {
    rugcheckError = String(rugRes.reason?.message || rugRes.reason);
  }

  const score = scoreToken({ mint, rugcheck: normalizeRugcheck(rugcheck), pair, rugcheckError, dexError });
  return cacheSet(mint, { mint, score, pair, rugcheck });
}

async function scoreMints(mints) {
  const unique = [...new Set((mints || []).filter(Boolean))];
  const results = {};
  await Promise.all(
    unique.map(async (mint) => {
      try {
        const row = await scoreMint(mint);
        results[mint] = row.score;
      } catch (err) {
        results[mint] = {
          level: "unknown",
          reasons: [`Could not score this mint: ${err.message || err}`],
          facts: { mint }
        };
      }
    })
  );
  return results;
}

async function loadEnabledFromSession() {
  try {
    const { enabledTabs = {} } = await chrome.storage.session.get("enabledTabs");
    Object.entries(enabledTabs).forEach(([id, on]) => {
      if (on) tabEnabled.set(Number(id), true);
    });
  } catch {
    // session storage may be unavailable in older browsers
  }
}

async function persistEnabled() {
  const enabledTabs = {};
  for (const [id, on] of tabEnabled.entries()) {
    if (on) enabledTabs[id] = true;
  }
  try {
    await chrome.storage.session.set({ enabledTabs });
  } catch {
    // ignore
  }
}

async function inject(tabId) {
  await chrome.scripting.insertCSS({ target: { tabId }, files: ["content.css"] });
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
}

async function setEnabled(tabId, enabled) {
  if (enabled) {
    tabEnabled.set(tabId, true);
    await persistEnabled();
    const tab = await chrome.tabs.get(tabId);
    if (!isPumpUrl(tab.url || "")) {
      throw new Error("Launchguard only runs on pump.fun tabs.");
    }
    await inject(tabId);
    if (chrome.sidePanel?.setOptions) {
      await chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
    }
    try {
      await chrome.tabs.sendMessage(tabId, { type: "LG_ENABLE" });
    } catch {
      // content script will enable itself on inject
    }
  } else {
    tabEnabled.delete(tabId);
    tabCoins.delete(tabId);
    await persistEnabled();
    try {
      await chrome.tabs.sendMessage(tabId, { type: "LG_DISABLE" });
    } catch {
      // tab may not have a content script
    }
    if (chrome.sidePanel?.setOptions) {
      try {
        await chrome.sidePanel.setOptions({ tabId, enabled: false });
      } catch {
        // ignore
      }
    }
  }
  return { enabled: !!tabEnabled.get(tabId) };
}

function snapshot(tabId) {
  const coins = tabCoins.get(tabId) || {};
  return {
    enabled: !!tabEnabled.get(tabId),
    coins
  };
}

chrome.runtime.onInstalled.addListener(() => {
  loadEnabledFromSession();
});
loadEnabledFromSession();

chrome.tabs.onRemoved.addListener((tabId) => {
  tabEnabled.delete(tabId);
  tabCoins.delete(tabId);
  persistEnabled();
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!tabEnabled.get(tabId)) return;
  if (changeInfo.status === "complete" && isPumpUrl(tab.url || "")) {
    try {
      await inject(tabId);
      await chrome.tabs.sendMessage(tabId, { type: "LG_ENABLE" });
    } catch {
      // ignore reload races
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = message.tabId || sender.tab?.id;
  const type = message.type;

  const reply = (promise) => {
    promise.then((value) => sendResponse({ ok: true, ...value })).catch((err) => {
      sendResponse({ ok: false, error: String(err.message || err) });
    });
    return true;
  };

  if (type === "LG_GET_STATUS") {
    return reply(
      Promise.resolve({
        enabled: tabId ? !!tabEnabled.get(tabId) : false,
        isPump: false
      }).then(async (base) => {
        let isPump = false;
        let url = "";
        if (tabId) {
          try {
            const tab = await chrome.tabs.get(tabId);
            url = tab.url || "";
            isPump = isPumpUrl(url);
          } catch {
            // ignore
          }
        }
        return { ...base, enabled: tabId ? !!tabEnabled.get(tabId) : false, isPump, url, snapshot: tabId ? snapshot(tabId) : null };
      })
    );
  }

  if (type === "LG_SET_ENABLED") {
    return reply(setEnabled(tabId, !!message.enabled).then((r) => ({ ...r })));
  }

  if (type === "LG_SCORE_MINTS") {
    return reply(
      scoreMints(message.mints || []).then((scores) => {
        if (tabId) {
          const current = tabCoins.get(tabId) || {};
          tabCoins.set(tabId, { ...current, ...scores });
        }
        return { scores };
      })
    );
  }

  if (type === "LG_COINS_UPDATED") {
    if (tabId) {
      tabCoins.set(tabId, message.coins || {});
      chrome.runtime.sendMessage({ type: "LG_TAB_COINS", tabId, coins: message.coins || {} }).catch(() => {});
    }
    sendResponse({ ok: true });
    return false;
  }

  if (type === "LG_GET_COINS") {
    sendResponse({ ok: true, snapshot: tabId ? snapshot(tabId) : { enabled: false, coins: {} } });
    return false;
  }

  return false;
});
