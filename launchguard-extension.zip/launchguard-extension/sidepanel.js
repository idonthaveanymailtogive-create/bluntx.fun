const list = document.getElementById("list");
const meta = document.getElementById("meta");

function label(level) {
  return level === "safe" ? "Safe" : level === "risky" ? "Risky" : level === "rug" ? "Rug" : "…";
}

function render(coins) {
  const entries = Object.entries(coins || {});
  const rank = { rug: 0, risky: 1, unknown: 2, safe: 3 };
  entries.sort((a, b) => (rank[a[1]?.level] ?? 9) - (rank[b[1]?.level] ?? 9));
  meta.textContent = entries.length ? `${entries.length} coin${entries.length === 1 ? "" : "s"} on this tab` : "Coins on this tab";
  if (!entries.length) {
    list.innerHTML = `<li class="empty">Turn Launchguard on for a pump.fun tab. Coins found on the page will show up here with a Safe, Risky or Rug score and the reasons.</li>`;
    return;
  }
  list.innerHTML = "";
  for (const [mint, score] of entries) {
    const level = score?.level || "unknown";
    const name = score?.facts?.symbol || score?.facts?.name || mint.slice(0, 6);
    const reasons = (score?.reasons || []).map((r) => `<li>${escapeHtml(r)}</li>`).join("");
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="row">
        <span class="lg-badge" data-level="${level}">${label(level)}</span>
        <span class="name">${escapeHtml(name)}</span>
      </div>
      <div class="mint">${escapeHtml(mint)}</div>
      <ul class="reasons">${reasons}</ul>
    `;
    list.appendChild(li);
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function load() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return render({});
  const res = await chrome.runtime.sendMessage({ type: "LG_GET_COINS", tabId: tab.id });
  render(res?.snapshot?.coins || {});
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "LG_TAB_COINS") render(message.coins || {});
});

load();
setInterval(load, 2000);
