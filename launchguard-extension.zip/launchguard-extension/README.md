# Launchguard for pump.fun (prototype)

A Chrome Manifest V3 extension that you turn on for a pump.fun tab. It finds coin links on the page, scores each one **Safe**, **Risky** or **Rug**, badges the card, and lists every coin in an on-page overlay and a Chrome side panel.

This is a prototype. It is not listed on the Chrome Web Store. It is not financial advice, and a score is not a guarantee.

## Install (unpacked)

1. Download and unzip `launchguard-extension.zip`, or clone this folder.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select this `launchguard-extension` folder.
5. Open [pump.fun](https://pump.fun), click the Launchguard icon, and switch **On for this tab**.

Do not publish this build to any web store.

## What it does

- The popup toggle enables Launchguard only for the current pump.fun tab.
- A content script scans the tab for coin links whose URL contains a Solana mint, especially `/coin/<mint>`.
- Each matching card gets a small Safe / Risky / Rug badge. Hover the badge to read the reasons.
- An overlay on the right lists every coin found. Chrome's side panel shows the same list with the full reasons.

## Data sources (tested without an API key)

Both of these responded with HTTP 200 and JSON in November 2026 from this environment, with no API key:

- **DexScreener** `GET https://api.dexscreener.com/latest/dex/tokens/<mint>[,<mint>…]`  
  Used for liquidity (`liquidity.usd`), 24h volume (`volume.h24`), market cap (`marketCap` or `fdv`), pair age (`pairCreatedAt`), dex id (`dexId`, e.g. `pumpfun` or `pumpswap`), and socials/websites (`info.socials`, `info.websites`). Batching multiple mints in one request works. Coins still on the pump.fun curve often have `liquidity: null`.
- **RugCheck** `GET https://api.rugcheck.xyz/v1/tokens/<mint>/report`  
  Used for mint authority, freeze authority, top-holder risk flags (`risks[]` with `name`, `value`, `description`, `level`, `score`), `rugged`, token name/symbol, and liquidity lock (`lpLockedPct` on the summary, or `markets[].lp.lpLockedPct` on the full report). The lighter `…/report/summary` endpoint also works without a key (risks, `score_normalised`, `lpLockedPct`) but does **not** include mint/freeze authority fields, so the full report is preferred. If the full report returns HTTP 429, the extension falls back to summary.

Requests run in the extension background worker (no page CORS). Results are cached for **5 minutes** in memory and `chrome.storage.local`. DexScreener calls are batched (up to 20 mints) and spaced at least 1.5s apart. RugCheck calls are one mint at a time and spaced at least 2s apart, with a backoff if HTTP 429 is returned.

### Limits found

- RugCheck sends `x-rate-limit-limit: 15`. There was no reset header. Remaining appeared to recover between requests a couple of seconds apart, but 15 is still treated as a low cap: the queue is conservative, and a busy board will take a while to finish scoring. Cached results reuse the 5-minute window.
- pump.fun itself is behind Cloudflare. This prototype does **not** call pump.fun APIs. It only reads the DOM of a tab you already opened.
- **pump.fun DOM selectors may change.** The scanner looks for `a[href]` values matching `/coin/<mint>` (and a mint in a pump.fun path). It does not depend on a specific card class name, but if pump.fun stops putting the mint in the link href, badges will stop appearing until the scanner is updated.
- A score is only marked Safe, Risky or Rug after a RugCheck response arrives. DexScreener-only data is shown as reasons under **Checking** (`unknown`), not as a made-up Safe rating.

## Scoring rules

Only fields actually returned by those APIs are used. Missing fields are skipped, not invented.

The result starts as **Checking** until RugCheck data is available.

**Rug** if any of these are true:

- RugCheck `rugged` is `true`.
- A RugCheck risk has `level` of `danger`, `critical`, or `rugged`.
- A RugCheck risk `name` matches honeypot, rug pull, rugged, or liquidity/LP removed.

**Risky** if it is not already Rug and any of these are true:

- A RugCheck risk has `level` of `warn` or `warning`.
- A RugCheck risk `name` refers to mint authority, freeze authority, holder concentration, single holder, or top-10 holders.
- `mintAuthority` or `freezeAuthority` is a non-null address.
- After the coin has left the pump.fun curve (`dexId` is present and not `pumpfun`), reported `lpLockedPct` is 0, or is greater than 0 but under 90%.

**Safe** if RugCheck returned a report and none of the Rug or Risky rules matched.

Reasons always include the facts that were present, even on a Safe coin, for example:

- Each RugCheck risk name, value and description.
- Mint/freeze authority still active, or revoked (`null`).
- Reported LP lock percentage, or a note that a coin still on the pump.fun curve has no lock yet (this alone does not make it Risky).
- DexScreener liquidity, market cap, 24h volume, pair age, and whether socials or a website are listed.
- If DexScreener lists no pool and `dexId` is `pumpfun`, the reason says the coin is still on the pump.fun curve. That is not treated as zero liquidity or a rug.

`score_normalised` is stored as a fact but is not used as a threshold. The label comes from the rules above, not from a made-up cutoff on that number.

## Files

- `manifest.json` — Chrome Manifest V3
- `background.js` — toggle, injection, API cache, rate limits
- `scoring.js` — scoring rules
- `content.js`, `content.css` — coin scanner, badges, on-page list
- `popup.html`, `popup.css`, `popup.js` — on/off for the current tab
- `sidepanel.html`, `sidepanel.css`, `sidepanel.js` — full reasons list
- `icons/` — toolbar icons

## Safety

Launchguard does not ask for your wallet, does not inject buy/sell transactions, and does not require a paid API key. Public data can be wrong or stale. Always do your own research.
